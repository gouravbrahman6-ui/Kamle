package com.example.ui.viewmodel

import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.crypto.E2eeCryptoManager
import com.example.data.model.CallSession
import com.example.data.model.CallStatus
import com.example.data.model.CallType
import com.example.data.model.ChatMessage
import com.example.data.model.Contact
import com.example.data.model.Conversation
import com.example.data.model.LastSeenVisibility
import com.example.data.model.MessageType
import com.example.data.model.QualityTier
import com.example.data.model.StatusUpdate
import com.example.data.model.UiState
import com.example.data.model.UserPrivate
import com.example.data.model.UserPublic
import com.example.data.preferences.ThemeMode
import com.example.data.preferences.UserPreferencesStore
import com.example.data.preferences.UserSettingsState
import com.example.data.repository.CipherChatRepository
import com.example.notifications.PresenceNotificationManager
import com.example.utils.MediaAttachmentHelper
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestoreException
import javax.crypto.SecretKey
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class DecryptedMessageUi(
    val raw: ChatMessage,
    val decryptedText: String,
    val decryptedMediaBytes: ByteArray?
)

class MainViewModel(
    private val currentUserId: String,
    private val repository: CipherChatRepository,
    private val crypto: E2eeCryptoManager,
    private val preferencesStore: UserPreferencesStore,
    private val notificationManager: PresenceNotificationManager
) : ViewModel() {

    private companion object {
        const val TAG = "MainViewModel"
        const val STOP_TIMEOUT_MS = 5000L
    }

    private val _statusBanner = MutableStateFlow<String?>(null)
    val statusBanner: StateFlow<String?> = _statusBanner.asStateFlow()

    private val _selectedConversationId = MutableStateFlow<String?>(null)
    val selectedConversationId: StateFlow<String?> = _selectedConversationId.asStateFlow()

    private val _activeCallId = MutableStateFlow<String?>(null)
    val activeCallId: StateFlow<String?> = _activeCallId.asStateFlow()

    private val previousOnlineMap = mutableMapOf<String, Boolean>()
    private val notifiedCallIds = mutableSetOf<String>()

    val settingsState: StateFlow<UserSettingsState> = preferencesStore.settingsFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS),
            initialValue = UserSettingsState()
        )

    val myProfileState: StateFlow<UiState<UserPublic?>> = repository.observeMyProfile(currentUserId)
        .toUiStateFlow("Failed to load profile")

    val myPrivateState: StateFlow<UiState<UserPrivate?>> = repository.observePrivateProfile(currentUserId)
        .toUiStateFlow("Failed to load private settings")

    val directoryUsersState: StateFlow<UiState<List<UserPublic>>> = repository.observeDiscoverableUsers()
        .map { users ->
            val others = users.filter { it.userId != currentUserId }
            val alertsEnabled = settingsState.value.onlineAlertsEnabled
            for (peer in others) {
                val prev = previousOnlineMap[peer.userId]
                if (prev == false && peer.online && alertsEnabled) {
                    val canSee = LastSeenVisibility.fromRaw(peer.lastSeenVisibility) != LastSeenVisibility.NOBODY
                    if (canSee) {
                        notificationManager.notifyFriendOnline(
                            friendName = peer.displayName.ifBlank { peer.handle },
                            friendUid = peer.userId
                        )
                    }
                }
                previousOnlineMap[peer.userId] = peer.online
            }
            others
        }
        .toUiStateFlow("Failed to load friends directory")

    val contactsState: StateFlow<UiState<List<Contact>>> = repository.observeContacts(currentUserId)
        .toUiStateFlow("Failed to load contacts")

    val conversationsState: StateFlow<UiState<List<Conversation>>> = repository.observeConversations(currentUserId)
        .toUiStateFlow("Failed to load conversations")

    val statusUpdatesState: StateFlow<UiState<List<StatusUpdate>>> = repository.observePublicStatuses()
        .toUiStateFlow("Failed to load status updates")

    val callsState: StateFlow<UiState<List<CallSession>>> = repository.observeCalls(currentUserId)
        .map { calls ->
            val incomingRinging = calls.firstOrNull {
                it.calleeId == currentUserId && it.status == CallStatus.RINGING.name
            }
            if (incomingRinging != null && notifiedCallIds.add(incomingRinging.id)) {
                notificationManager.notifyIncomingCall(
                    callerName = incomingRinging.callerName,
                    callType = incomingRinging.callType,
                    callId = incomingRinging.id
                )
            }
            calls
        }
        .toUiStateFlow("Failed to load call history")

    @OptIn(ExperimentalCoroutinesApi::class)
    val selectedMessagesState: StateFlow<UiState<List<DecryptedMessageUi>>> =
        combine(
            _selectedConversationId,
            conversationsState,
            directoryUsersState,
            myProfileState
        ) { convId, convUi, usersUi, meUi ->
            val conv = (convUi as? UiState.Success)?.data?.firstOrNull { it.id == convId }
            val peers = (usersUi as? UiState.Success)?.data.orEmpty()
            val me = (meUi as? UiState.Success)?.data
            val map = (peers + listOfNotNull(me)).associateBy { it.userId }
            Triple(convId, conv, map)
        }.flatMapLatest { (convId, conv, usersMap) ->
            if (convId.isNullOrBlank()) {
                flowOf(UiState.Success(emptyList()))
            } else {
                val secretKey: SecretKey = if (conv != null) {
                    repository.resolveConversationSecretKey(conv, currentUserId, usersMap)
                } else {
                    crypto.deriveConversationFallbackKey(convId)
                }
                repository.observeMessages(convId, currentUserId)
                    .map<List<ChatMessage>, UiState<List<DecryptedMessageUi>>> { list ->
                        val decrypted = list.map { msg ->
                            val text = crypto.decryptText(msg.encryptedPayload, secretKey)
                                ?: "[Encrypted payload — verify E2EE key]"
                            val media = msg.encryptedMediaBase64?.let { crypto.decryptBytes(it, secretKey) }
                            DecryptedMessageUi(
                                raw = msg,
                                decryptedText = text,
                                decryptedMediaBytes = media
                            )
                        }
                        UiState.Success(decrypted)
                    }
                    .catch { error ->
                        val fsErr = generateSequence(error) { it.cause }
                            .filterIsInstance<FirebaseFirestoreException>()
                            .firstOrNull()
                        if (fsErr == null && error is CancellationException) throw error
                        val root = fsErr ?: error
                        Log.w(TAG, "Error observing messages", root)
                        emit(UiState.Error(root.message ?: "Failed to load messages"))
                    }
            }
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS),
            initialValue = UiState.Loading
        )

    private fun <T> Flow<T>.toUiStateFlow(fallbackError: String): StateFlow<UiState<T>> =
        map<T, UiState<T>> { UiState.Success(it) }
            .catch { error ->
                val fsErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (fsErr == null && error is CancellationException) throw error
                val root = fsErr ?: error
                Log.w(TAG, fallbackError, root)
                emit(UiState.Error(root.message ?: fallbackError))
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS),
                initialValue = UiState.Loading
            )

    fun bootstrapUser(firebaseUser: FirebaseUser) {
        viewModelScope.launch {
            val res = repository.ensureUserProvisioned(firebaseUser)
            if (res.isFailure) {
                _statusBanner.value = res.exceptionOrNull()?.localizedMessage ?: "Profile sync failed"
            }
        }
    }

    fun setOnlinePresence(online: Boolean) {
        viewModelScope.launch {
            repository.updatePresence(currentUserId, online)
        }
    }

    fun clearBanner() {
        _statusBanner.value = null
    }

    fun openConversation(conversationId: String?) {
        _selectedConversationId.value = conversationId
    }

    fun startOrOpenDirectChat(peer: UserPublic, onOpened: (String) -> Unit) {
        val me = (myProfileState.value as? UiState.Success)?.data ?: return
        viewModelScope.launch {
            repository.addContact(currentUserId, peer)
            val result = repository.createOrOpenDirectChat(me, peer)
            result.onSuccess { convId ->
                _selectedConversationId.value = convId
                onOpened(convId)
            }.onFailure { err ->
                _statusBanner.value = err.localizedMessage ?: "Unable to start chat"
            }
        }
    }

    fun createGroupChat(title: String, selectedFriends: List<UserPublic>, onCreated: (String) -> Unit) {
        val me = (myProfileState.value as? UiState.Success)?.data ?: return
        viewModelScope.launch {
            val result = repository.createGroupChat(me, title, selectedFriends)
            result.onSuccess { convId ->
                _selectedConversationId.value = convId
                onCreated(convId)
            }.onFailure { err ->
                _statusBanner.value = err.localizedMessage ?: "Unable to create group"
            }
        }
    }

    fun sendTextMessage(conversation: Conversation, text: String) {
        val me = (myProfileState.value as? UiState.Success)?.data ?: return
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return
        viewModelScope.launch {
            val usersMap = buildUsersMap()
            val secretKey = repository.resolveConversationSecretKey(conversation, currentUserId, usersMap)
            val result = repository.sendEncryptedMessage(
                conversation = conversation,
                sender = me,
                plainText = trimmed,
                messageType = MessageType.TEXT,
                secretKey = secretKey
            )
            if (result.isFailure) {
                _statusBanner.value = result.exceptionOrNull()?.localizedMessage ?: "Failed to send message"
            }
        }
    }

    fun sendVisualMediaMessage(
        context: Context,
        conversation: Conversation,
        uri: Uri,
        caption: String
    ) {
        val me = (myProfileState.value as? UiState.Success)?.data ?: return
        viewModelScope.launch {
            val mime = context.contentResolver.getType(uri) ?: "image/jpeg"
            val isVideo = mime.startsWith("video/")
            val bytes = if (isVideo) {
                MediaAttachmentHelper.extractVideoThumbnailBytes(context, uri)
            } else {
                MediaAttachmentHelper.compressImageUriToBytes(context, uri)
            }
            if (bytes == null) {
                _statusBanner.value = "Could not process selected media"
                return@launch
            }
            val docMeta = MediaAttachmentHelper.readDocumentMetadataAndPreview(context, uri)
            val usersMap = buildUsersMap()
            val secretKey = repository.resolveConversationSecretKey(conversation, currentUserId, usersMap)
            val result = repository.sendEncryptedMessage(
                conversation = conversation,
                sender = me,
                plainText = caption.ifBlank { if (isVideo) "HD Video Clip" else "Photo" },
                messageType = if (isVideo) MessageType.VIDEO else MessageType.IMAGE,
                secretKey = secretKey,
                attachmentName = docMeta?.fileName ?: if (isVideo) "video.mp4" else "photo.jpg",
                attachmentMime = mime,
                attachmentSizeBytes = (docMeta?.sizeBytes ?: bytes.size.toLong()),
                rawMediaBytes = bytes
            )
            if (result.isFailure) {
                _statusBanner.value = result.exceptionOrNull()?.localizedMessage ?: "Failed to send media"
            }
        }
    }

    fun sendDocumentMessage(context: Context, conversation: Conversation, uri: Uri) {
        val me = (myProfileState.value as? UiState.Success)?.data ?: return
        viewModelScope.launch {
            val doc = MediaAttachmentHelper.readDocumentMetadataAndPreview(context, uri)
            if (doc == null) {
                _statusBanner.value = "Unable to read document"
                return@launch
            }
            val usersMap = buildUsersMap()
            val secretKey = repository.resolveConversationSecretKey(conversation, currentUserId, usersMap)
            val result = repository.sendEncryptedMessage(
                conversation = conversation,
                sender = me,
                plainText = "${doc.fileName} (${MediaAttachmentHelper.formatFileSize(doc.sizeBytes)})",
                messageType = MessageType.DOCUMENT,
                secretKey = secretKey,
                attachmentName = doc.fileName,
                attachmentMime = doc.mimeType,
                attachmentSizeBytes = doc.sizeBytes,
                rawMediaBytes = doc.inlineBytes
            )
            if (result.isFailure) {
                _statusBanner.value = result.exceptionOrNull()?.localizedMessage ?: "Failed to send document"
            }
        }
    }

    fun startCall(peer: UserPublic, conversationId: String, callType: CallType) {
        val me = (myProfileState.value as? UiState.Success)?.data ?: return
        val quality = QualityTier.fromRaw(settingsState.value.preferredQuality)
        viewModelScope.launch {
            val result = repository.startCall(
                caller = me,
                callee = peer,
                conversationId = conversationId,
                callType = callType,
                qualityTier = quality
            )
            result.onSuccess { session ->
                _activeCallId.value = session.id
            }.onFailure { err ->
                _statusBanner.value = err.localizedMessage ?: "Could not start call"
            }
        }
    }

    fun joinCall(callId: String) {
        _activeCallId.value = callId
        viewModelScope.launch {
            repository.updateCallStatus(callId, CallStatus.ACTIVE)
        }
    }

    fun declineCall(callId: String) {
        if (_activeCallId.value == callId) _activeCallId.value = null
        viewModelScope.launch {
            repository.updateCallStatus(callId, CallStatus.DECLINED)
        }
    }

    fun endCall(callId: String) {
        if (_activeCallId.value == callId) _activeCallId.value = null
        viewModelScope.launch {
            repository.updateCallStatus(callId, CallStatus.ENDED)
        }
    }

    fun updateCallQuality(callId: String, tier: QualityTier) {
        viewModelScope.launch {
            preferencesStore.setPreferredCallQuality(tier.name)
            repository.updateCallStatus(callId, CallStatus.ACTIVE, tier)
        }
    }

    fun postTextStatus(caption: String, backgroundHex: String) {
        val me = (myProfileState.value as? UiState.Success)?.data ?: return
        viewModelScope.launch {
            val res = repository.postStatusUpdate(me, caption, backgroundHex, null)
            if (res.isFailure) {
                _statusBanner.value = res.exceptionOrNull()?.localizedMessage ?: "Status post failed"
            }
        }
    }

    fun postImageStatus(context: Context, uri: Uri, caption: String) {
        val me = (myProfileState.value as? UiState.Success)?.data ?: return
        viewModelScope.launch {
            val b64 = MediaAttachmentHelper.compressImageUriToBase64(context, uri, 640, 220_000)
            if (b64 == null) {
                _statusBanner.value = "Failed to compress status photo"
                return@launch
            }
            val res = repository.postStatusUpdate(me, caption, "#0B1324", b64)
            if (res.isFailure) {
                _statusBanner.value = res.exceptionOrNull()?.localizedMessage ?: "Status post failed"
            }
        }
    }

    fun markStatusViewed(status: StatusUpdate) {
        viewModelScope.launch {
            repository.markStatusViewed(status, currentUserId)
        }
    }

    fun updateProfile(
        displayName: String,
        handle: String,
        bio: String,
        avatarPreset: String,
        avatarBase64: String?,
        lastSeenVisibility: LastSeenVisibility,
        discoverable: Boolean
    ) {
        viewModelScope.launch {
            val res = repository.updateProfile(
                userId = currentUserId,
                displayName = displayName,
                handle = handle,
                bio = bio,
                avatarPreset = avatarPreset,
                avatarBase64 = avatarBase64,
                lastSeenVisibility = lastSeenVisibility,
                discoverable = discoverable
            )
            _statusBanner.value = if (res.isSuccess) {
                "Profile & privacy settings saved"
            } else {
                res.exceptionOrNull()?.localizedMessage ?: "Failed to update profile"
            }
        }
    }

    fun savePhoneNumber(phone: String) {
        viewModelScope.launch {
            val res = repository.updatePhoneVerification(currentUserId, phone, verified = true)
            _statusBanner.value = if (res.isSuccess) {
                "Phone number linked to your CipherChat profile"
            } else {
                res.exceptionOrNull()?.localizedMessage ?: "Could not save phone number"
            }
        }
    }

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch { preferencesStore.setThemeMode(mode) }
    }

    fun setOnlineAlertsEnabled(enabled: Boolean) {
        viewModelScope.launch { preferencesStore.setOnlineAlertsEnabled(enabled) }
    }

    fun setReadReceiptsEnabled(enabled: Boolean) {
        viewModelScope.launch { preferencesStore.setReadReceiptsEnabled(enabled) }
    }

    private fun buildUsersMap(): Map<String, UserPublic> {
        val peers = (directoryUsersState.value as? UiState.Success)?.data.orEmpty()
        val me = (myProfileState.value as? UiState.Success)?.data
        return (peers + listOfNotNull(me)).associateBy { it.userId }
    }
}
