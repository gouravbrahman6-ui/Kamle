package com.example.ui.components

import android.graphics.BitmapFactory
import android.util.Base64
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.data.model.LastSeenVisibility
import com.example.data.model.UserPublic
import com.example.ui.theme.EmeraldOnline
import com.google.firebase.Timestamp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class AvatarStylePreset(
    val id: String,
    val label: String,
    val colors: List<Color>
)

val AVATAR_PRESETS = listOf(
    AvatarStylePreset("TEAL_SHIELD", "Electric Teal", listOf(Color(0xFF00E5C3), Color(0xFF0F766E))),
    AvatarStylePreset("INDIGO_WAVE", "Indigo Glow", listOf(Color(0xFF818CF8), Color(0xFF4338CA))),
    AvatarStylePreset("CORAL_SUN", "Coral Flame", listOf(Color(0xFFFB7185), Color(0xFFBE123C))),
    AvatarStylePreset("AMBER_DUSK", "Amber Dusk", listOf(Color(0xFFFBBF24), Color(0xFFB45309))),
    AvatarStylePreset("EMERALD_MINT", "Emerald", listOf(Color(0xFF34D399), Color(0xFF047857))),
    AvatarStylePreset("VIOLET_NEON", "Cyber Violet", listOf(Color(0xFFC084FC), Color(0xFF6D28D9)))
)

@Composable
fun UserAvatar(
    name: String,
    avatarPreset: String,
    avatarBase64: String? = null,
    size: Dp = 48.dp,
    showOnlineDot: Boolean = false,
    isGroup: Boolean = false
) {
    val preset = AVATAR_PRESETS.firstOrNull { it.id == avatarPreset } ?: AVATAR_PRESETS.first()
    val bitmap = remember(avatarBase64) {
        if (!avatarBase64.isNullOrBlank()) {
            runCatching {
                val bytes = Base64.decode(avatarBase64, Base64.DEFAULT)
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap()
            }.getOrNull()
        } else null
    }

    Box(modifier = Modifier.size(size)) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .clip(CircleShape)
                .background(Brush.linearGradient(preset.colors)),
            contentAlignment = Alignment.Center
        ) {
            if (bitmap != null) {
                Image(
                    bitmap = bitmap,
                    contentDescription = "$name avatar",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            } else if (isGroup) {
                Icon(
                    imageVector = Icons.Filled.Groups,
                    contentDescription = "$name group icon",
                    tint = Color.White,
                    modifier = Modifier.size(size * 0.52f)
                )
            } else {
                val initials = name.trim()
                    .split(Regex("\\s+"))
                    .filter { it.isNotEmpty() }
                    .take(2)
                    .joinToString("") { it.first().uppercase() }
                    .ifEmpty { "C" }
                Text(
                    text = initials,
                    style = if (size >= 56.dp) MaterialTheme.typography.titleLarge else MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }
        if (showOnlineDot) {
            Box(
                modifier = Modifier
                    .size((size * 0.28f).coerceAtLeast(11.dp))
                    .align(Alignment.BottomEnd)
                    .clip(CircleShape)
                    .background(EmeraldOnline)
                    .border(2.dp, MaterialTheme.colorScheme.surface, CircleShape)
            )
        }
    }
}

@Composable
fun E2eeShieldChip(
    label: String = "End-to-End Encrypted",
    modifier: Modifier = Modifier
) {
    Surface(
        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f),
        shape = RoundedCornerShape(50),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Filled.Lock,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(13.dp)
            )
            Spacer(Modifier.width(5.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onPrimaryContainer
            )
        }
    }
}

@Composable
fun E2eeVerificationDialog(
    title: String,
    myFingerprint: String,
    peerFingerprint: String?,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Icon(
                imageVector = Icons.Filled.VerifiedUser,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary
            )
        },
        title = { Text("Verify Security Keys") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Messages, media, documents, and calls in $title are protected with ECDH P-256 key exchange and AES-256-GCM encryption.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("Your Device Key", style = MaterialTheme.typography.labelMedium)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = myFingerprint.ifBlank { "Generating…" },
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                        if (!peerFingerprint.isNullOrBlank()) {
                            Spacer(Modifier.height(10.dp))
                            Text("Peer Public Key", style = MaterialTheme.typography.labelMedium)
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = peerFingerprint,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Verified")
            }
        }
    )
}

fun formatLastSeenLabel(peer: UserPublic?, isFriend: Boolean): String {
    if (peer == null) return "Encrypted Chat"
    val vis = LastSeenVisibility.fromRaw(peer.lastSeenVisibility)
    if (vis == LastSeenVisibility.NOBODY) return "Last seen hidden"
    if (vis == LastSeenVisibility.CONTACTS && !isFriend) return "Encrypted Chat"
    if (peer.online) return "Online now"
    val ts = peer.lastSeenAt ?: peer.updatedAt ?: return "Offline"
    val formatted = SimpleDateFormat("h:mm a", Locale.getDefault()).format(ts.toDate())
    return "Last seen at $formatted"
}

fun formatTimestampShort(timestamp: Timestamp?): String {
    val date: Date = timestamp?.toDate() ?: return "Now"
    return SimpleDateFormat("h:mm a", Locale.getDefault()).format(date)
}
