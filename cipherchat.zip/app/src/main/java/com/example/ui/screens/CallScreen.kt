package com.example.ui.screens

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.HighQuality
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VideocamOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.data.model.CallSession
import com.example.data.model.CallStatus
import com.example.data.model.CallType
import com.example.data.model.QualityTier
import com.example.data.model.UiState
import com.example.data.model.UserPublic
import com.example.ui.components.UserAvatar
import com.example.ui.components.formatTimestampShort
import com.example.ui.theme.CoralAlert
import com.example.ui.theme.EmeraldOnline
import kotlin.math.abs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext

@Composable
fun CallsHistoryScreen(
    currentUserId: String,
    callsState: UiState<List<CallSession>>,
    peers: List<UserPublic>,
    onStartCall: (UserPublic, CallType) -> Unit
) {
    val peersById = remember(peers) { peers.associateBy { it.userId } }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
    ) {
        Spacer(Modifier.height(14.dp))
        Text(
            text = "Encrypted Calls",
            style = MaterialTheme.typography.headlineMedium
        )
        Text(
            text = "HD Audio & Video • ECDH Verified",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(Modifier.height(14.dp))

        if (peers.isNotEmpty()) {
            Text(
                text = "QUICK CALL",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(8.dp))
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(peers, key = { it.userId }) { friend ->
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)
                        ),
                        shape = RoundedCornerShape(18.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            UserAvatar(
                                name = friend.displayName,
                                avatarPreset = friend.avatarPreset,
                                avatarBase64 = friend.avatarBase64,
                                size = 44.dp,
                                showOnlineDot = friend.online
                            )
                            Spacer(Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = friend.displayName.ifBlank { friend.handle },
                                    style = MaterialTheme.typography.titleSmall
                                )
                                Text(
                                    text = if (friend.online) "Available for HD call" else "@${friend.handle}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(
                                onClick = { onStartCall(friend, CallType.AUDIO) },
                                modifier = Modifier.testTag("quick_audio_call_${friend.userId}")
                            ) {
                                Icon(Icons.Filled.Call, contentDescription = "Audio Call")
                            }
                            IconButton(
                                onClick = { onStartCall(friend, CallType.VIDEO) },
                                modifier = Modifier.testTag("quick_video_call_${friend.userId}")
                            ) {
                                Icon(
                                    Icons.Filled.Videocam,
                                    contentDescription = "Video Call",
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }

                val history = (callsState as? UiState.Success)?.data.orEmpty()
                if (history.isNotEmpty()) {
                    item {
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = "RECENT CALL LOG",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    items(history, key = { it.id }) { call ->
                        val isOutgoing = call.callerId == currentUserId
                        val peerName = if (isOutgoing) call.calleeName else call.callerName
                        val peerId = if (isOutgoing) call.calleeId else call.callerId
                        val peer = peersById[peerId]
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = if (call.callType == CallType.VIDEO.name) Icons.Filled.Videocam else Icons.Filled.Call,
                                    contentDescription = null,
                                    tint = if (call.status == CallStatus.DECLINED.name) CoralAlert else MaterialTheme.colorScheme.primary
                                )
                                Spacer(Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(peerName, style = MaterialTheme.typography.titleSmall)
                                    Text(
                                        text = "${if (isOutgoing) "Outgoing" else "Incoming"} • ${call.status} • ${formatTimestampShort(call.createdAt)}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                if (peer != null) {
                                    IconButton(
                                        onClick = {
                                            onStartCall(peer, CallType.fromRaw(call.callType))
                                        }
                                    ) {
                                        Icon(Icons.Filled.Call, contentDescription = "Redial")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    text = "Add or discover friends in Chats to place encrypted HD audio & video calls.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun ActiveCallScreen(
    call: CallSession,
    isIncomingRinging: Boolean,
    onAccept: () -> Unit,
    onDecline: () -> Unit,
    onEnd: () -> Unit,
    onQualityChange: (QualityTier) -> Unit
) {
    BackHandler { onEnd() }

    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    val isVideoCall = call.callType == CallType.VIDEO.name
    var micMuted by remember { mutableStateOf(false) }
    var cameraEnabled by remember { mutableStateOf(isVideoCall) }
    var useFrontCamera by remember { mutableStateOf(true) }
    var speakerOn by remember { mutableStateOf(isVideoCall) }
    var showQualityMenu by remember { mutableStateOf(false) }
    var elapsedSeconds by remember { mutableIntStateOf(0) }
    var micAmplitude by remember { mutableFloatStateOf(0.15f) }

    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }
    var hasAudioPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        hasCameraPermission = results[Manifest.permission.CAMERA] ?: hasCameraPermission
        hasAudioPermission = results[Manifest.permission.RECORD_AUDIO] ?: hasAudioPermission
    }

    LaunchedEffect(Unit) {
        val needed = buildList {
            if (!hasAudioPermission) add(Manifest.permission.RECORD_AUDIO)
            if (isVideoCall && !hasCameraPermission) add(Manifest.permission.CAMERA)
        }
        if (needed.isNotEmpty()) {
            permissionLauncher.launch(needed.toTypedArray())
        }
    }

    // Speakerphone AudioManager control
    DisposableEffect(speakerOn) {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
        @Suppress("DEPRECATION")
        audioManager.isSpeakerphoneOn = speakerOn
        onDispose {
            @Suppress("DEPRECATION")
            audioManager.isSpeakerphoneOn = false
            audioManager.mode = AudioManager.MODE_NORMAL
        }
    }

    // Call duration timer
    LaunchedEffect(call.status) {
        if (call.status == CallStatus.ACTIVE.name) {
            while (isActive) {
                delay(1000L)
                elapsedSeconds++
            }
        }
    }

    // Live AudioRecord microphone meter when permitted & unmuted
    LaunchedEffect(hasAudioPermission, micMuted, call.status) {
        if (hasAudioPermission && !micMuted && call.status != CallStatus.ENDED.name) {
            withContext(Dispatchers.IO) {
                val sampleRate = 16000
                val minBuf = AudioRecord.getMinBufferSize(
                    sampleRate,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                )
                if (minBuf > 0) {
                    val recorder = runCatching {
                        @Suppress("MissingPermission")
                        AudioRecord(
                            MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                            sampleRate,
                            AudioFormat.CHANNEL_IN_MONO,
                            AudioFormat.ENCODING_PCM_16BIT,
                            minBuf
                        )
                    }.getOrNull()
                    if (recorder != null && recorder.state == AudioRecord.STATE_INITIALIZED) {
                        val buf = ShortArray(minBuf / 2)
                        runCatching {
                            recorder.startRecording()
                            while (isActive) {
                                val read = recorder.read(buf, 0, buf.size)
                                if (read > 0) {
                                    var peak = 0
                                    for (i in 0 until read) {
                                        val v = abs(buf[i].toInt())
                                        if (v > peak) peak = v
                                    }
                                    micAmplitude = (peak / 18000f).coerceIn(0.1f, 1f)
                                }
                                delay(90L)
                            }
                        }
                        runCatching { recorder.stop() }
                        recorder.release()
                    }
                }
            }
        } else {
            micAmplitude = 0.08f
        }
    }

    val peerName = if (isIncomingRinging) call.callerName else call.calleeName
    val currentQuality = QualityTier.fromRaw(call.qualityTier)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF060A13), Color(0xFF0E1A2F), Color(0xFF060A13))
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        // Real CameraX Video Stream Preview
        if (cameraEnabled && hasCameraPermission) {
            AndroidView(
                factory = { ctx -> PreviewView(ctx) },
                update = { previewView ->
                    val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
                    cameraProviderFuture.addListener({
                        runCatching {
                            val cameraProvider = cameraProviderFuture.get()
                            val preview = Preview.Builder().build().also {
                                it.surfaceProvider = previewView.surfaceProvider
                            }
                            val selector = if (useFrontCamera) {
                                CameraSelector.DEFAULT_FRONT_CAMERA
                            } else {
                                CameraSelector.DEFAULT_BACK_CAMERA
                            }
                            cameraProvider.unbindAll()
                            cameraProvider.bindToLifecycle(lifecycleOwner, selector, preview)
                        }
                    }, ContextCompat.getMainExecutor(context))
                },
                modifier = Modifier.fillMaxSize()
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.28f))
            )
        }

        // Top E2EE & Quality bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                color = Color.Black.copy(alpha = 0.55f),
                shape = RoundedCornerShape(50)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.Lock,
                        contentDescription = null,
                        tint = Color(0xFF00E5C3),
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = "E2EE • ${call.e2eeFingerprint.take(9)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White
                    )
                }
            }

            Box {
                Surface(
                    color = Color.Black.copy(alpha = 0.55f),
                    shape = RoundedCornerShape(50),
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .clickable { showQualityMenu = true }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Filled.HighQuality,
                            contentDescription = "Stream quality",
                            tint = Color(0xFF00E5C3),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = currentQuality.label,
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White
                        )
                    }
                }
                DropdownMenu(
                    expanded = showQualityMenu,
                    onDismissRequest = { showQualityMenu = false }
                ) {
                    QualityTier.entries.forEach { tier ->
                        DropdownMenuItem(
                            text = { Text(tier.label) },
                            onClick = {
                                showQualityMenu = false
                                onQualityChange(tier)
                            }
                        )
                    }
                }
            }
        }

        // Center Avatar & Live Audio Waveform
        Column(
            modifier = Modifier
                .align(Alignment.Center)
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (!cameraEnabled || !hasCameraPermission) {
                UserAvatar(
                    name = peerName,
                    avatarPreset = "TEAL_SHIELD",
                    size = 112.dp
                )
                Spacer(Modifier.height(18.dp))
            }
            Text(
                text = peerName,
                style = MaterialTheme.typography.headlineMedium,
                color = Color.White
            )
            Spacer(Modifier.height(6.dp))
            val statusText = when {
                isIncomingRinging -> "Incoming Encrypted ${if (isVideoCall) "Video" else "Audio"} Call…"
                call.status == CallStatus.RINGING.name -> "Ringing • Signaling via Firestore…"
                call.status == CallStatus.ACTIVE.name -> {
                    val m = elapsedSeconds / 60
                    val s = elapsedSeconds % 60
                    String.format("%02d:%02d • HD Stream Active", m, s)
                }
                else -> call.status
            }
            Text(
                text = statusText,
                style = MaterialTheme.typography.bodyMedium,
                color = Color(0xFFCBD5E1)
            )

            Spacer(Modifier.height(18.dp))
            // Live Audio Amplitude Visualizer
            Row(
                horizontalArrangement = Arrangement.spacedBy(5.dp),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.height(32.dp)
            ) {
                listOf(0.45f, 0.8f, 1.0f, 0.7f, 0.5f).forEach { factor ->
                    Box(
                        modifier = Modifier
                            .width(6.dp)
                            .height((10 + (22 * micAmplitude * factor)).dp)
                            .clip(CircleShape)
                            .background(if (micMuted) Color.Gray else Color(0xFF00E5C3))
                    )
                }
            }
        }

        // Bottom Controls
        if (isIncomingRinging) {
            Row(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(horizontal = 36.dp, vertical = 32.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Button(
                    onClick = onDecline,
                    colors = ButtonDefaults.buttonColors(containerColor = CoralAlert),
                    shape = CircleShape,
                    modifier = Modifier
                        .size(72.dp)
                        .testTag("decline_call_button")
                ) {
                    Icon(Icons.Filled.CallEnd, contentDescription = "Decline call", tint = Color.White)
                }
                Button(
                    onClick = onAccept,
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldOnline),
                    shape = CircleShape,
                    modifier = Modifier
                        .size(72.dp)
                        .testTag("accept_call_button")
                ) {
                    Icon(Icons.Filled.Call, contentDescription = "Accept call", tint = Color.White)
                }
            }
        } else {
            Surface(
                color = Color.Black.copy(alpha = 0.65f),
                shape = RoundedCornerShape(28.dp),
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(horizontal = 20.dp, vertical = 24.dp)
                    .border(1.dp, Color.White.copy(alpha = 0.14f), RoundedCornerShape(28.dp))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CallToggleIcon(
                        active = !micMuted,
                        icon = if (micMuted) Icons.Filled.MicOff else Icons.Filled.Mic,
                        desc = "Toggle Microphone",
                        onClick = { micMuted = !micMuted }
                    )
                    CallToggleIcon(
                        active = cameraEnabled,
                        icon = if (cameraEnabled) Icons.Filled.Videocam else Icons.Filled.VideocamOff,
                        desc = "Toggle Camera",
                        onClick = { cameraEnabled = !cameraEnabled }
                    )
                    if (cameraEnabled && hasCameraPermission) {
                        CallToggleIcon(
                            active = true,
                            icon = Icons.Filled.Cameraswitch,
                            desc = "Switch Camera",
                            onClick = { useFrontCamera = !useFrontCamera }
                        )
                    }
                    CallToggleIcon(
                        active = speakerOn,
                        icon = Icons.Filled.VolumeUp,
                        desc = "Toggle Speakerphone",
                        onClick = { speakerOn = !speakerOn }
                    )
                    Surface(
                        color = CoralAlert,
                        shape = CircleShape,
                        modifier = Modifier
                            .size(54.dp)
                            .clip(CircleShape)
                            .clickable(onClick = onEnd)
                            .testTag("end_call_button")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Filled.CallEnd, contentDescription = "End Call", tint = Color.White)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CallToggleIcon(
    active: Boolean,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    desc: String,
    onClick: () -> Unit
) {
    Surface(
        color = if (active) Color.White.copy(alpha = 0.2f) else Color.White.copy(alpha = 0.08f),
        shape = CircleShape,
        modifier = Modifier
            .size(48.dp)
            .clip(CircleShape)
            .clickable(onClick = onClick)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(
                imageVector = icon,
                contentDescription = desc,
                tint = Color.White
            )
        }
    }
}
