package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddComment
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GroupAdd
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.RadioButtonUnchecked
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.Conversation
import com.example.data.model.ConversationType
import com.example.data.model.LastSeenVisibility
import com.example.data.model.UiState
import com.example.data.model.UserPublic
import com.example.ui.components.E2eeShieldChip
import com.example.ui.components.UserAvatar
import com.example.ui.components.formatLastSeenLabel
import com.example.ui.components.formatTimestampShort

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatsScreen(
    currentUserId: String,
    myProfile: UserPublic?,
    conversationsState: UiState<List<Conversation>>,
    directoryUsersState: UiState<List<UserPublic>>,
    onOpenConversation: (Conversation) -> Unit,
    onStartDirectChat: (UserPublic) -> Unit,
    onCreateGroupChat: (String, List<UserPublic>) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var filterIndex by remember { mutableIntStateOf(0) } // 0 = All, 1 = Direct, 2 = Groups
    var showNewChatSheet by remember { mutableStateOf(false) }
    var showNewGroupDialog by remember { mutableStateOf(false) }

    val peers = (directoryUsersState as? UiState.Success)?.data.orEmpty()
    val peersById = remember(peers) { peers.associateBy { it.userId } }
    val onlinePeers = remember(peers) {
        peers.filter {
            it.online && LastSeenVisibility.fromRaw(it.lastSeenVisibility) != LastSeenVisibility.NOBODY
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "CipherChat",
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Spacer(Modifier.height(2.dp))
                    E2eeShieldChip(label = "E2EE Active • ${myProfile?.keyFingerprint?.take(9) ?: "Ready"}")
                }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    IconButton(
                        onClick = { showNewGroupDialog = true },
                        modifier = Modifier.testTag("create_group_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.GroupAdd,
                            contentDescription = "New Group Chat",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            // Search bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search chats or friends…") },
                leadingIcon = {
                    Icon(Icons.Filled.Search, contentDescription = null)
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Filled.Close, contentDescription = "Clear search")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
                    .testTag("chats_search_input")
            )

            // Online Friends Strip
            if (onlinePeers.isNotEmpty()) {
                Spacer(Modifier.height(14.dp))
                Text(
                    text = "ONLINE NOW",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(horizontal = 20.dp)
                )
                Spacer(Modifier.height(8.dp))
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    items(onlinePeers, key = { it.userId }) { friend ->
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .width(66.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .clickable { onStartDirectChat(friend) }
                                .padding(4.dp)
                                .testTag("online_friend_${friend.userId}")
                        ) {
                            UserAvatar(
                                name = friend.displayName,
                                avatarPreset = friend.avatarPreset,
                                avatarBase64 = friend.avatarBase64,
                                size = 50.dp,
                                showOnlineDot = true
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = friend.displayName.ifBlank { friend.handle },
                                style = MaterialTheme.typography.labelMedium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }

            // Filter Chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("All", "Direct", "Groups").forEachIndexed { idx, label ->
                    FilterChip(
                        selected = filterIndex == idx,
                        onClick = { filterIndex = idx },
                        label = { Text(label) },
                        modifier = Modifier.testTag("filter_chip_${label.lowercase()}")
                    )
                }
            }

            // Conversation List
            when (conversationsState) {
                is UiState.Loading -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }
                is UiState.Error -> {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = conversationsState.message,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }
                is UiState.Success -> {
                    val filtered = conversationsState.data.filter { conv ->
                        val matchesType = when (filterIndex) {
                            1 -> conv.conversationType == ConversationType.DIRECT.name
                            2 -> conv.conversationType == ConversationType.GROUP.name
                            else -> true
                        }
                        val displayTitle = resolveConversationTitle(conv, currentUserId, peersById)
                        val matchesQuery = searchQuery.isBlank() ||
                            displayTitle.contains(searchQuery, ignoreCase = true) ||
                            conv.lastMessagePreview.contains(searchQuery, ignoreCase = true)
                        matchesType && matchesQuery
                    }

                    if (filtered.isEmpty()) {
                        EmptyChatsState(onStartNewChat = { showNewChatSheet = true })
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(
                                start = 16.dp,
                                end = 16.dp,
                                top = 4.dp,
                                bottom = 92.dp
                            ),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(filtered, key = { it.id }) { conv ->
                                val isGroup = conv.conversationType == ConversationType.GROUP.name
                                val peerId = if (!isGroup) conv.memberUids.firstOrNull { it != currentUserId } else null
                                val peer = peerId?.let { peersById[it] }
                                val title = resolveConversationTitle(conv, currentUserId, peersById)
                                val showDot = !isGroup && peer?.online == true &&
                                    LastSeenVisibility.fromRaw(peer.lastSeenVisibility) != LastSeenVisibility.NOBODY

                                ConversationCard(
                                    title = title,
                                    preview = conv.lastMessagePreview,
                                    timeLabel = formatTimestampShort(conv.updatedAt ?: conv.createdAt),
                                    avatarPreset = peer?.avatarPreset ?: "INDIGO_WAVE",
                                    avatarBase64 = peer?.avatarBase64,
                                    isGroup = isGroup,
                                    memberCount = conv.memberUids.size,
                                    showOnlineDot = showDot,
                                    onClick = { onOpenConversation(conv) }
                                )
                            }
                        }
                    }
                }
            }
        }

        FloatingActionButton(
            onClick = { showNewChatSheet = true },
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary,
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp)
                .testTag("new_chat_fab")
        ) {
            Icon(Icons.Filled.AddComment, contentDescription = "Start new encrypted chat")
        }
    }

    if (showNewChatSheet) {
        ModalBottomSheet(onDismissRequest = { showNewChatSheet = false }) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp)
            ) {
                Text(
                    text = "Start Encrypted Chat",
                    style = MaterialTheme.typography.titleLarge
                )
                Text(
                    text = "Select a friend from the CipherChat directory",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(14.dp))
                if (peers.isEmpty()) {
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "No other users online in directory yet. Sign in from another device/account to chat in real time!",
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.height(320.dp)
                    ) {
                        items(peers, key = { it.userId }) { peer ->
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        showNewChatSheet = false
                                        onStartDirectChat(peer)
                                    }
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    UserAvatar(
                                        name = peer.displayName,
                                        avatarPreset = peer.avatarPreset,
                                        avatarBase64 = peer.avatarBase64,
                                        size = 44.dp,
                                        showOnlineDot = peer.online &&
                                            LastSeenVisibility.fromRaw(peer.lastSeenVisibility) != LastSeenVisibility.NOBODY
                                    )
                                    Spacer(Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = peer.displayName.ifBlank { peer.handle },
                                            style = MaterialTheme.typography.titleSmall
                                        )
                                        Text(
                                            text = "@${peer.handle} • ${formatLastSeenLabel(peer, isFriend = true)}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Icon(
                                        imageVector = Icons.Filled.Lock,
                                        contentDescription = "E2EE ready",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(20.dp))
            }
        }
    }

    if (showNewGroupDialog) {
        CreateGroupDialog(
            peers = peers,
            onDismiss = { showNewGroupDialog = false },
            onCreate = { title, selected ->
                showNewGroupDialog = false
                onCreateGroupChat(title, selected)
            }
        )
    }
}

@Composable
private fun ConversationCard(
    title: String,
    preview: String,
    timeLabel: String,
    avatarPreset: String,
    avatarBase64: String?,
    isGroup: Boolean,
    memberCount: Int,
    showOnlineDot: Boolean,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)
        ),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("conversation_card")
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            UserAvatar(
                name = title,
                avatarPreset = avatarPreset,
                avatarBase64 = avatarBase64,
                size = 52.dp,
                showOnlineDot = showOnlineDot,
                isGroup = isGroup
            )
            Spacer(Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = timeLabel,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.Lock,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(Modifier.width(5.dp))
                    Text(
                        text = if (isGroup) "$memberCount members • $preview" else preview,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
private fun EmptyChatsState(onStartNewChat: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.img_empty_chat),
            contentDescription = "No encrypted conversations yet",
            modifier = Modifier
                .size(190.dp)
                .clip(RoundedCornerShape(24.dp)),
            contentScale = ContentScale.Crop
        )
        Spacer(Modifier.height(18.dp))
        Text(
            text = "Your Encrypted Inbox is Ready",
            style = MaterialTheme.typography.titleLarge
        )
        Spacer(Modifier.height(6.dp))
        Text(
            text = "Start a private chat or create a group with end-to-end encryption, HD video calls, and media sharing.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(18.dp))
        Button(
            onClick = onStartNewChat,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .height(48.dp)
                .testTag("empty_start_chat_button")
        ) {
            Text("Find Friends to Chat")
        }
    }
}

@Composable
private fun CreateGroupDialog(
    peers: List<UserPublic>,
    onDismiss: () -> Unit,
    onCreate: (String, List<UserPublic>) -> Unit
) {
    var groupTitle by remember { mutableStateOf("") }
    val selectedUids = remember { mutableStateListOf<String>() }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New Encrypted Group") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = groupTitle,
                    onValueChange = { groupTitle = it },
                    label = { Text("Group Name") },
                    placeholder = { Text("e.g. Squad, Family, Dev Team") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("group_title_input")
                )
                Text(
                    text = "Select friends (${selectedUids.size} selected)",
                    style = MaterialTheme.typography.labelMedium
                )
                if (peers.isEmpty()) {
                    Text(
                        text = "No other friends in directory yet.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    LazyColumn(modifier = Modifier.height(180.dp)) {
                        items(peers, key = { it.userId }) { peer ->
                            val isSelected = selectedUids.contains(peer.userId)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable {
                                        if (isSelected) selectedUids.remove(peer.userId)
                                        else selectedUids.add(peer.userId)
                                    }
                                    .padding(vertical = 8.dp, horizontal = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = if (isSelected) Icons.Filled.CheckCircle else Icons.Outlined.RadioButtonUnchecked,
                                    contentDescription = null,
                                    tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(Modifier.width(10.dp))
                                Text(
                                    text = peer.displayName.ifBlank { peer.handle },
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val chosen = peers.filter { selectedUids.contains(it.userId) }
                    onCreate(groupTitle, chosen)
                },
                enabled = groupTitle.trim().isNotEmpty() && selectedUids.isNotEmpty(),
                modifier = Modifier.testTag("confirm_create_group_button")
            ) {
                Text("Create Group")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

fun resolveConversationTitle(
    conversation: Conversation,
    currentUserId: String,
    peersById: Map<String, UserPublic>
): String {
    if (conversation.conversationType == ConversationType.GROUP.name) {
        return conversation.title.ifBlank { "Encrypted Group" }
    }
    val peerId = conversation.memberUids.firstOrNull { it != currentUserId }
    val peer = peerId?.let { peersById[it] }
    return peer?.displayName?.ifBlank { peer.handle }
        ?: conversation.memberNames[peerId]?.takeIf { it.isNotBlank() }
        ?: conversation.title.ifBlank { "Encrypted Chat" }
}
