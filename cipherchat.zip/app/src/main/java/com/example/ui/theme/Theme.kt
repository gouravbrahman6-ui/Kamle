package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val CipherDarkColorScheme = darkColorScheme(
    primary = ElectricTeal,
    onPrimary = OnElectricTeal,
    primaryContainer = TealContainer,
    onPrimaryContainer = OnTealContainer,
    secondary = IndigoAccent,
    onSecondary = TextPrimaryDark,
    secondaryContainer = IndigoContainer,
    onSecondaryContainer = OnIndigoContainer,
    tertiary = AmberStatus,
    background = ObsidianBg,
    onBackground = TextPrimaryDark,
    surface = ObsidianSurface,
    onSurface = TextPrimaryDark,
    surfaceVariant = ObsidianSurfaceVariant,
    onSurfaceVariant = TextSecondaryDark,
    surfaceContainerHigh = ObsidianContainerHigh,
    outline = OutlineDark,
    error = CoralAlert,
    onError = ObsidianBg
)

private val CipherLightColorScheme = lightColorScheme(
    primary = DeepTeal,
    onPrimary = OnDeepTeal,
    primaryContainer = DeepTealContainer,
    onPrimaryContainer = OnDeepTealContainer,
    secondary = RoyalIndigo,
    onSecondary = OnDeepTeal,
    secondaryContainer = RoyalIndigoContainer,
    onSecondaryContainer = OnRoyalIndigoContainer,
    tertiary = AmberStatus,
    background = DaylightBg,
    onBackground = TextPrimaryLight,
    surface = DaylightSurface,
    onSurface = TextPrimaryLight,
    surfaceVariant = DaylightSurfaceVariant,
    onSurfaceVariant = TextSecondaryLight,
    surfaceContainerHigh = DaylightContainerHigh,
    outline = OutlineLight,
    error = CoralAlert,
    onError = OnDeepTeal
)

val CipherShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(30.dp)
)

@Composable
fun CipherChatTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) CipherDarkColorScheme else CipherLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = CipherTypography,
        shapes = CipherShapes,
        content = content
    )
}
