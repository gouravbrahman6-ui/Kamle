package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Obsidian & Electric Teal Dark Palette
val ObsidianBg = Color(0xFF070B14)
val ObsidianSurface = Color(0xFF0E1525)
val ObsidianSurfaceVariant = Color(0xFF172033)
val ObsidianContainerHigh = Color(0xFF1E2A42)
val ElectricTeal = Color(0xFF00E5C3)
val OnElectricTeal = Color(0xFF00382E)
val TealContainer = Color(0xFF083A36)
val OnTealContainer = Color(0xFF7DFCE4)
val IndigoAccent = Color(0xFF7C83FF)
val IndigoContainer = Color(0xFF232854)
val OnIndigoContainer = Color(0xFFDDE0FF)
val CoralAlert = Color(0xFFFF5E7E)
val EmeraldOnline = Color(0xFF22C55E)
val AmberStatus = Color(0xFFF59E0B)

val TextPrimaryDark = Color(0xFFF1F5F9)
val TextSecondaryDark = Color(0xFF94A3B8)
val OutlineDark = Color(0xFF28354D)

// Crisp Daylight Light Palette
val DaylightBg = Color(0xFFF4F7FB)
val DaylightSurface = Color(0xFFFFFFFF)
val DaylightSurfaceVariant = Color(0xFFE7EEF7)
val DaylightContainerHigh = Color(0xFFDCE6F2)
val DeepTeal = Color(0xFF00796B)
val OnDeepTeal = Color(0xFFFFFFFF)
val DeepTealContainer = Color(0xFFC2F5EC)
val OnDeepTealContainer = Color(0xFF00201C)
val RoyalIndigo = Color(0xFF4F46E5)
val RoyalIndigoContainer = Color(0xFFE0E7FF)
val OnRoyalIndigoContainer = Color(0xFF1E1B4B)

val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF475569)
val OutlineLight = Color(0xFFCBD5E1)
