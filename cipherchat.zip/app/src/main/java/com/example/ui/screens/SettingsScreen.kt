package com.example.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.model.LastSeenVisibility
import com.example.data.model.UserPrivate
import com.example.data.model.UserPublic
import com.example.data.preferences.ThemeMode
import com.example.data.preferences.UserSettingsState
import com.example.ui.components.AVATAR_PRESETS
import com.example.ui.components.UserAvatar
import com.example.utils.MediaAttachmentHelper
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    myProfile: UserPublic?,
    myPrivate: UserPrivate?,
    settings: UserSettingsState,
    onUpdateProfile: (String, String, String, String, String?, LastSeenVisibility, Boolean) -> Unit,
    onSavePhoneNumber: (String) -> Unit,
    onSetThemeMode: (ThemeMode) -> Unit,
    onSetOnlineAlerts: (Boolean) -> Unit,
    onSetReadReceipts: (Boolean) -> Unit,
    onSignOut: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var showEditProfile by remember { mutableStateOf(false) }
    var showPhoneDialog by remember { mutableStateOf(false) }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
        onResult = { granted ->
            onSetOnlineAlerts(granted)
        }
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            text = "Profile & Privacy",
            style = MaterialTheme.typography.headlineMedium
        )

        // Profile Summary Card
        Card(
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f)
            ),
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    UserAvatar(
                        name = myProfile?.displayName ?: "Cipher User",
                        avatarPreset = myProfile?.avatarPreset ?: "TEAL_SHIELD",
                        avatarBase64 = myProfile?.avatarBase64,
                        size = 64.dp,
                        showOnlineDot = true
                    )
                    Spacer(Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = myProfile?.displayName ?: "Loading…",
                            style = MaterialTheme.typography.titleLarge
                        )
                        Text(
                            text = "@${myProfile?.handle ?: "user"}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                        if (!myProfile?.bio.isNullOrBlank()) {
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = myProfile?.bio ?: "",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    OutlinedButton(
                        onClick = { showEditProfile = true },
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.testTag("edit_profile_button")
                    ) {
                        Icon(Icons.Filled.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Edit")
                    }
                }
                Spacer(Modifier.height(14.dp))
                Surface(
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.7f),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Shield,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text("E2EE Identity Key Fingerprint", style = MaterialTheme.typography.labelMedium)
                            Text(
                                text = myProfile?.keyFingerprint ?: "Generating…",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }
        }

        // Appearance (Dark Mode Support)
        Card(
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            ),
            shape = RoundedCornerShape(22.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Appearance", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(10.dp))
                SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                    ThemeMode.entries.forEachIndexed { idx, mode ->
                        SegmentedButton(
                            selected = settings.themeMode == mode,
                            onClick = { onSetThemeMode(mode) },
                            shape = SegmentedButtonDefaults.itemShape(index = idx, count = ThemeMode.entries.size),
                            modifier = Modifier.testTag("theme_mode_${mode.name.lowercase()}")
                        ) {
                            Text(mode.name.lowercase().replaceFirstChar { it.uppercase() })
                        }
                    }
                }
            }
        }

        // Privacy, Last Seen & Notifications
        Card(
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            ),
            shape = RoundedCornerShape(22.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("Privacy & Notifications", style = MaterialTheme.typography.titleMedium)

                // Last Seen Visibility
                val currentVis = LastSeenVisibility.fromRaw(myProfile?.lastSeenVisibility)
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Filled.Visibility,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text("Last Seen & Online Visibility", style = MaterialTheme.typography.titleSmall)
                    }
                    Spacer(Modifier.height(8.dp))
                    SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                        LastSeenVisibility.entries.forEachIndexed { idx, vis ->
                            SegmentedButton(
                                selected = currentVis == vis,
                                onClick = {
                                    myProfile?.let { prof ->
                                        onUpdateProfile(
                                            prof.displayName,
                                            prof.handle,
                                            prof.bio,
                                            prof.avatarPreset,
                                            prof.avatarBase64,
                                            vis,
                                            prof.discoverable
                                        )
                                    }
                                },
                                shape = SegmentedButtonDefaults.itemShape(index = idx, count = LastSeenVisibility.entries.size),
                                modifier = Modifier.testTag("last_seen_${vis.name.lowercase()}")
                            ) {
                                Text(vis.label, maxLines = 1)
                            }
                        }
                    }
                }

                // Online Friend Alerts
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            Icons.Filled.NotificationsActive,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text("Online Friend Alerts", style = MaterialTheme.typography.titleSmall)
                            Text(
                                text = "Notify as soon as friends come online",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Switch(
                        checked = settings.onlineAlertsEnabled,
                        onCheckedChange = { wantEnable ->
                            if (wantEnable && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                            } else {
                                onSetOnlineAlerts(wantEnable)
                            }
                        },
                        modifier = Modifier.testTag("online_alerts_switch")
                    )
                }

                // Read Receipts
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Read Receipts", style = MaterialTheme.typography.titleSmall)
                        Text(
                            text = "Share message & status view receipts",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = settings.readReceiptsEnabled,
                        onCheckedChange = onSetReadReceipts,
                        modifier = Modifier.testTag("read_receipts_switch")
                    )
                }
            }
        }

        // Phone Number & OTP Linking
        Card(
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            ),
            shape = RoundedCornerShape(22.dp),
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(22.dp))
                .clickable { showPhoneDialog = true }
                .testTag("phone_linking_card")
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Filled.PhoneAndroid,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Spacer(Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text("Phone Number & OTP", style = MaterialTheme.typography.titleSmall)
                    val phoneLabel = myPrivate?.phoneNumber?.takeIf { it.isNotBlank() }
                        ?: "Tap to link your phone number"
                    Text(
                        text = phoneLabel,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Text(
                    text = if (myPrivate?.phoneVerified == true) "Linked" else "Add",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }

        // Sign Out
        Button(
            onClick = onSignOut,
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.error.copy(alpha = 0.16f),
                contentColor = MaterialTheme.colorScheme.error
            ),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .testTag("sign_out_button")
        ) {
            Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Sign Out")
        }

        Spacer(Modifier.height(16.dp))
    }

    if (showEditProfile && myProfile != null) {
        var name by remember { mutableStateOf(myProfile.displayName) }
        var handle by remember { mutableStateOf(myProfile.handle) }
        var bio by remember { mutableStateOf(myProfile.bio) }
        var preset by remember { mutableStateOf(myProfile.avatarPreset) }
        var avatarB64 by remember { mutableStateOf(myProfile.avatarBase64) }
        var discoverable by remember { mutableStateOf(myProfile.discoverable) }

        val avatarPicker = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.PickVisualMedia(),
            onResult = { uri ->
                if (uri != null) {
                    scope.launch {
                        val encoded = MediaAttachmentHelper.compressImageUriToBase64(context, uri, 320, 90_000)
                        if (encoded != null) avatarB64 = encoded
                    }
                }
            }
        )

        AlertDialog(
            onDismissRequest = { showEditProfile = false },
            title = { Text("Customize Profile") },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.verticalScroll(rememberScrollState())
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        UserAvatar(
                            name = name,
                            avatarPreset = preset,
                            avatarBase64 = avatarB64,
                            size = 56.dp
                        )
                        Spacer(Modifier.width(12.dp))
                        OutlinedButton(
                            onClick = {
                                avatarPicker.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            }
                        ) {
                            Icon(Icons.Filled.PhotoCamera, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Upload Photo")
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AVATAR_PRESETS.forEach { item ->
                            Box(
                                modifier = Modifier
                                    .size(30.dp)
                                    .clip(CircleShape)
                                    .background(Brush.linearGradient(item.colors))
                                    .border(
                                        width = if (preset == item.id && avatarB64 == null) 2.5.dp else 0.dp,
                                        color = Color.White,
                                        shape = CircleShape
                                    )
                                    .clickable {
                                        preset = item.id
                                        avatarB64 = null
                                    }
                            )
                        }
                    }

                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Display Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = handle,
                        onValueChange = { handle = it },
                        label = { Text("Handle (@username)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = bio,
                        onValueChange = { bio = it },
                        label = { Text("About / Status Bio") },
                        maxLines = 2,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Discoverable in Friends List", style = MaterialTheme.typography.bodySmall)
                        Switch(checked = discoverable, onCheckedChange = { discoverable = it })
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showEditProfile = false
                        onUpdateProfile(
                            name,
                            handle,
                            bio,
                            preset,
                            avatarB64,
                            LastSeenVisibility.fromRaw(myProfile.lastSeenVisibility),
                            discoverable
                        )
                    },
                    enabled = name.isNotBlank() && handle.trim().length >= 2
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditProfile = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    if (showPhoneDialog) {
        var phoneInput by remember { mutableStateOf(myPrivate?.phoneNumber ?: "+91") }
        AlertDialog(
            onDismissRequest = { showPhoneDialog = false },
            title = { Text("Link Phone Number") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Add your mobile number to your private CipherChat profile. To enable carrier SMS OTP login, turn on the Phone provider in your Firebase Console.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedTextField(
                        value = phoneInput,
                        onValueChange = { phoneInput = it },
                        label = { Text("Phone Number (with country code)") },
                        placeholder = { Text("+919876543210") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("phone_number_input")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showPhoneDialog = false
                        onSavePhoneNumber(phoneInput)
                    },
                    enabled = phoneInput.trim().length >= 6,
                    modifier = Modifier.testTag("save_phone_button")
                ) {
                    Text("Save Number")
                }
            },
            dismissButton = {
                TextButton(onClick = { showPhoneDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
