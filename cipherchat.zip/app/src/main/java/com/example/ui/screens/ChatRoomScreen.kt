package com.example.ui.screens

import android.content.Intent
import android.graphics.BitmapFactory
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PlayCircleFilled
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.core.content.FileProvider
import com.example.R
import com.example.data.model.CallType
import com.example.data.model.Conversation
import com.example.data.model.ConversationType
import com.example.data.model.LastSeenVisibility
import com.example.data.model.MessageType
import com.example.data.model.UiState
import com.example.data.model.UserPublic
import com.example.ui.components.E2eeVerificationDialog
import com.example.ui.components.UserAvatar
import com.example.ui.components.formatLastSeenLabel
import com.example.ui.components.formatTimestampShort
import com.example.ui.viewmodel.DecryptedMessageUi
import com.example.utils.MediaAttachmentHelper
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatRoomScreen(
    currentUserId: String,
    myProfile: UserPublic?,
    conversation: Conversation,
    peerProfile: UserPublic?,
    messagesState: UiState<List<DecryptedMessageUi>>,
    onBack: () -> Unit,
    onSendText: (String) -> Unit,
    onSendVisualMedia: (android.net.Uri, String) -> Unit,
    onSendDocument: (android.net.Uri) -> Unit,
    onStartCall: (UserPublic, CallType) -> Unit
) {
    BackHandler { onBack() }

    val context = LocalContext.current
    var draftText by remember { mutableStateOf("") }
    var showSecurityDialog by remember { mutableStateOf(false) }
    var previewBytes by remember { mutableStateOf<ByteArray?>(null) }
    var infoNotice by remember { mutableStateOf<String?>(null) }
    val listState = rememberLazyListState()

    val isGroup = conversation.conversationType == ConversationType.GROUP.name
    val title = if (isGroup) conversation.title else (peerProfile?.displayName?.ifBlank { peerProfile.handle } ?: conversation.title)
    val subtitle = if (isGroup) {
        "${conversation.memberUids.size} members • E2EE Group"
    } else {
        formatLastSeenLabel(peerProfile, isFriend = true)
    }

    // Zero-permission Photo & Video Picker (Play Policy Compliant)
    val mediaPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
        onResult = { uri ->
            if (uri != null) {
                onSendVisualMedia(uri, draftText)
                draftText = ""
            }
        }
    )

    // Zero-permission SAF Document Picker (Play Policy Compliant)
    val documentPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
        onResult = { uri ->
            if (uri != null) {
                onSendDocument(uri)
            }
        }
    )

    val messageList = (messagesState as? UiState.Success)?.data.orEmpty()
    LaunchedEffect(messageList.size) {
        if (messageList.isNotEmpty()) {
            listState.animateScrollToItem(messageList.size - 1)
        }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .imePadding(),
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("chat_back_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back to chats")
                    }
                },
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable { showSecurityDialog = true }
                    ) {
                        UserAvatar(
                            name = title,
                            avatarPreset = peerProfile?.avatarPreset ?: "INDIGO_WAVE",
                            avatarBase64 = peerProfile?.avatarBase64,
                            size = 40.dp,
                            showOnlineDot = !isGroup && peerProfile?.online == true &&
                                LastSeenVisibility.fromRaw(peerProfile.lastSeenVisibility) != LastSeenVisibility.NOBODY,
                            isGroup = isGroup
                        )
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(
                                text = title,
                                style = MaterialTheme.typography.titleMedium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = subtitle,
                                style = MaterialTheme.typography.bodySmall,
                                color = if (!isGroup && peerProfile?.online == true)
                                    MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1
                            )
                        }
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showSecurityDialog = true },
                        modifier = Modifier.testTag("chat_e2ee_verify_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Shield,
                            contentDescription = "Verify E2EE Keys",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                    if (!isGroup && peerProfile != null) {
                        IconButton(
                            onClick = { onStartCall(peerProfile, CallType.AUDIO) },
                            modifier = Modifier.testTag("chat_audio_call_button")
                        ) {
                            Icon(Icons.Filled.Call, contentDescription = "Start Audio Call")
                        }
                        IconButton(
                            onClick = { onStartCall(peerProfile, CallType.VIDEO) },
                            modifier = Modifier.testTag("chat_video_call_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Videocam,
                                contentDescription = "Start Video Call",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            )
        },
        bottomBar = {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 3.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = {
                            mediaPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)
                            )
                        },
                        modifier = Modifier.testTag("attach_media_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.PhotoLibrary,
                            contentDescription = "Share photo or video",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                    IconButton(
                        onClick = { documentPickerLauncher.launch(arrayOf("*/*")) },
                        modifier = Modifier.testTag("attach_document_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.AttachFile,
                            contentDescription = "Share document"
                        )
                    }
                    OutlinedTextField(
                        value = draftText,
                        onValueChange = { draftText = it },
                        placeholder = { Text(stringResource(R.string.type_message_hint)) },
                        maxLines = 4,
                        shape = RoundedCornerShape(22.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("message_input_field")
                    )
                    Spacer(Modifier.width(8.dp))
                    Surface(
                        color = MaterialTheme.colorScheme.primary,
                        shape = CircleShape,
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .clickable(enabled = draftText.isNotBlank()) {
                                val text = draftText
                                draftText = ""
                                onSendText(text)
                            }
                            .testTag("send_message_button")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Send,
                                contentDescription = "Send encrypted message",
                                tint = MaterialTheme.colorScheme.onPrimary
                            )
                        }
                    }
                }
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            when (messagesState) {
                is UiState.Loading -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }
                is UiState.Error -> {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = messagesState.message,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }
                is UiState.Success -> {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        item {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Surface(
                                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f),
                                    shape = RoundedCornerShape(14.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.Lock,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(13.dp)
                                        )
                                        Spacer(Modifier.width(6.dp))
                                        Text(
                                            text = "Messages & attachments are end-to-end encrypted.",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onPrimaryContainer
                                        )
                                    }
                                }
                            }
                        }

                        items(messagesState.data, key = { it.raw.id }) { item ->
                            val isMine = item.raw.senderId == currentUserId
                            MessageBubble(
                                item = item,
                                isMine = isMine,
                                showSenderName = isGroup && !isMine,
                                onMediaClick = { bytes -> previewBytes = bytes },
                                onDocumentClick = { msgItem ->
                                    val bytes = msgItem.decryptedMediaBytes
                                    if (bytes == null) {
                                        infoNotice = "Document metadata synced: ${msgItem.raw.attachmentName} (${MediaAttachmentHelper.formatFileSize(msgItem.raw.attachmentSizeBytes)})"
                                    } else {
                                        runCatching {
                                            val cacheFile = File(context.cacheDir, msgItem.raw.attachmentName ?: "doc.bin")
                                            cacheFile.writeBytes(bytes)
                                            infoNotice = "Decrypted ${cacheFile.name} (${MediaAttachmentHelper.formatFileSize(bytes.size.toLong())}) safely in app cache."
                                        }.onFailure {
                                            infoNotice = "Unable to open document preview."
                                        }
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
    }

    if (showSecurityDialog) {
        E2eeVerificationDialog(
            title = title,
            myFingerprint = myProfile?.keyFingerprint ?: "",
            peerFingerprint = peerProfile?.keyFingerprint,
            onDismiss = { showSecurityDialog = false }
        )
    }

    previewBytes?.let { bytes ->
        Dialog(onDismissRequest = { previewBytes = null }) {
            val bmp = remember(bytes) {
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap()
            }
            Surface(
                shape = RoundedCornerShape(22.dp),
                color = MaterialTheme.colorScheme.surface
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Decrypted Media", style = MaterialTheme.typography.titleSmall)
                        IconButton(onClick = { previewBytes = null }) {
                            Icon(Icons.Filled.Close, contentDescription = "Close preview")
                        }
                    }
                    if (bmp != null) {
                        Image(
                            bitmap = bmp,
                            contentDescription = "Full media preview",
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(360.dp),
                            contentScale = ContentScale.Fit
                        )
                    }
                }
            }
        }
    }

    infoNotice?.let { msg ->
        AlertDialog(
            onDismissRequest = { infoNotice = null },
            title = { Text("Encrypted Document") },
            text = { Text(msg) },
            confirmButton = {
                TextButton(onClick = { infoNotice = null }) {
                    Text("OK")
                }
            }
        )
    }
}

@Composable
private fun MessageBubble(
    item: DecryptedMessageUi,
    isMine: Boolean,
    showSenderName: Boolean,
    onMediaClick: (ByteArray) -> Unit,
    onDocumentClick: (DecryptedMessageUi) -> Unit
) {
    val msg = item.raw
    val msgType = MessageType.fromRaw(msg.messageType)
    val bubbleColor = if (isMine) {
        MaterialTheme.colorScheme.primaryContainer
    } else {
        MaterialTheme.colorScheme.surfaceVariant
    }
    val textColor = if (isMine) {
        MaterialTheme.colorScheme.onPrimaryContainer
    } else {
        MaterialTheme.colorScheme.onSurface
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isMine) Arrangement.End else Arrangement.Start
    ) {
        Surface(
            color = bubbleColor,
            shape = RoundedCornerShape(
                topStart = 18.dp,
                topEnd = 18.dp,
                bottomStart = if (isMine) 18.dp else 4.dp,
                bottomEnd = if (isMine) 4.dp else 18.dp
            ),
            modifier = Modifier.widthIn(max = 300.dp)
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                if (showSenderName) {
                    Text(
                        text = msg.senderName,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(Modifier.height(2.dp))
                }

                when (msgType) {
                    MessageType.IMAGE, MessageType.VIDEO -> {
                        val bmp = remember(item.decryptedMediaBytes) {
                            item.decryptedMediaBytes?.let { bytes ->
                                BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap()
                            }
                        }
                        if (bmp != null) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(180.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .clickable {
                                        item.decryptedMediaBytes?.let(onMediaClick)
                                    }
                            ) {
                                Image(
                                    bitmap = bmp,
                                    contentDescription = item.decryptedText,
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                                if (msgType == MessageType.VIDEO) {
                                    Icon(
                                        imageVector = Icons.Filled.PlayCircleFilled,
                                        contentDescription = "Video attachment",
                                        tint = Color.White,
                                        modifier = Modifier
                                            .size(46.dp)
                                            .align(Alignment.Center)
                                    )
                                }
                            }
                            Spacer(Modifier.height(6.dp))
                        }
                        Text(
                            text = item.decryptedText,
                            style = MaterialTheme.typography.bodyMedium,
                            color = textColor
                        )
                    }
                    MessageType.DOCUMENT -> {
                        Surface(
                            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.65f),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onDocumentClick(item) }
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Description,
                                    contentDescription = "Document",
                                    tint = MaterialTheme.colorScheme.primary
                                )
                                Spacer(Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = msg.attachmentName ?: "Document",
                                        style = MaterialTheme.typography.titleSmall,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "${MediaAttachmentHelper.formatFileSize(msg.attachmentSizeBytes)} • ${msg.attachmentMime ?: "file"}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                    else -> {
                        Text(
                            text = item.decryptedText,
                            style = MaterialTheme.typography.bodyLarge,
                            color = textColor
                        )
                    }
                }

                Spacer(Modifier.height(4.dp))
                Row(
                    modifier = Modifier.align(Alignment.End),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.Lock,
                        contentDescription = null,
                        tint = textColor.copy(alpha = 0.6f),
                        modifier = Modifier.size(10.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(
                        text = formatTimestampShort(msg.createdAt),
                        style = MaterialTheme.typography.labelSmall,
                        color = textColor.copy(alpha = 0.7f)
                    )
                }
            }
        }
    }
}
