package com.example.utils

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import java.io.ByteArrayOutputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class PickedDocumentPayload(
    val fileName: String,
    val mimeType: String,
    val sizeBytes: Long,
    val inlineBytes: ByteArray?
)

object MediaAttachmentHelper {

    suspend fun compressImageUriToBytes(
        context: Context,
        uri: Uri,
        maxDimension: Int = 720,
        maxBytes: Int = 220_000
    ): ByteArray? = withContext(Dispatchers.IO) {
        runCatching {
            val resolver = context.contentResolver
            val boundsOpts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, boundsOpts) }

            var sampleSize = 1
            val maxSide = maxOf(boundsOpts.outWidth, boundsOpts.outHeight)
            while (maxSide / sampleSize > maxDimension * 2) {
                sampleSize *= 2
            }

            val decodeOpts = BitmapFactory.Options().apply { inSampleSize = sampleSize }
            val original = resolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, decodeOpts)
            } ?: return@withContext null

            val ratio = minOf(
                maxDimension.toFloat() / original.width.coerceAtLeast(1),
                maxDimension.toFloat() / original.height.coerceAtLeast(1),
                1f
            )
            val targetW = (original.width * ratio).toInt().coerceAtLeast(1)
            val targetH = (original.height * ratio).toInt().coerceAtLeast(1)
            val scaled = if (targetW != original.width || targetH != original.height) {
                Bitmap.createScaledBitmap(original, targetW, targetH, true).also {
                    if (it !== original) original.recycle()
                }
            } else original

            var quality = 82
            val out = ByteArrayOutputStream()
            do {
                out.reset()
                scaled.compress(Bitmap.CompressFormat.JPEG, quality, out)
                quality -= 12
            } while (out.size() > maxBytes && quality >= 30)

            scaled.recycle()
            out.toByteArray()
        }.getOrNull()
    }

    suspend fun compressImageUriToBase64(
        context: Context,
        uri: Uri,
        maxDimension: Int = 512,
        maxBytes: Int = 180_000
    ): String? {
        val bytes = compressImageUriToBytes(context, uri, maxDimension, maxBytes) ?: return null
        return Base64.encodeToString(bytes, Base64.NO_WRAP)
    }

    suspend fun extractVideoThumbnailBytes(
        context: Context,
        uri: Uri
    ): ByteArray? = withContext(Dispatchers.IO) {
        runCatching {
            val retriever = MediaMetadataRetriever()
            retriever.setDataSource(context, uri)
            val frame = retriever.getFrameAtTime(0)
            retriever.release()
            frame?.let { bmp ->
                val ratio = minOf(640f / bmp.width.coerceAtLeast(1), 640f / bmp.height.coerceAtLeast(1), 1f)
                val scaled = Bitmap.createScaledBitmap(
                    bmp,
                    (bmp.width * ratio).toInt().coerceAtLeast(1),
                    (bmp.height * ratio).toInt().coerceAtLeast(1),
                    true
                )
                if (scaled !== bmp) bmp.recycle()
                val out = ByteArrayOutputStream()
                scaled.compress(Bitmap.CompressFormat.JPEG, 75, out)
                scaled.recycle()
                out.toByteArray()
            }
        }.getOrNull()
    }

    suspend fun readDocumentMetadataAndPreview(
        context: Context,
        uri: Uri
    ): PickedDocumentPayload? = withContext(Dispatchers.IO) {
        runCatching {
            val resolver = context.contentResolver
            val mime = resolver.getType(uri) ?: "application/octet-stream"
            var fileName = "document"
            var size = 0L

            resolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (cursor.moveToFirst()) {
                    if (nameIdx >= 0) fileName = cursor.getString(nameIdx) ?: fileName
                    if (sizeIdx >= 0) size = cursor.getLong(sizeIdx)
                }
            }

            val inlineBytes = if (size in 1L..280_000L) {
                resolver.openInputStream(uri)?.use { it.readBytes() }
            } else {
                null
            }

            PickedDocumentPayload(
                fileName = fileName,
                mimeType = mime,
                sizeBytes = size.coerceAtLeast(inlineBytes?.size?.toLong() ?: 0L),
                inlineBytes = inlineBytes
            )
        }.getOrNull()
    }

    fun formatFileSize(bytes: Long): String {
        if (bytes <= 0L) return "0 B"
        return when {
            bytes < 1024 -> "$bytes B"
            bytes < 1024 * 1024 -> "${bytes / 1024} KB"
            else -> String.format("%.1f MB", bytes / (1024.0 * 1024.0))
        }
    }
}
