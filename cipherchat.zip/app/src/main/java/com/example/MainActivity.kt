package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.DonutLarge
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Call
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.DonutLarge
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.crypto.E2eeCryptoManager
import com.example.data.model.CallStatus
import com.example.data.model.ConversationType
import com.example.data.model.UiState
import com.example.data.preferences.ThemeMode
import com.example.data.preferences.UserPreferencesStore
import com.example.data.repository.CipherChatRepository
import com.example.notifications.PresenceNotificationManager
import com.example.ui.auth.AuthScreen
import com.example.ui.auth.attemptAutoSignIn
import com.example.ui.auth.signOutUser
import com.example.ui.screens.ActiveCallScreen
import com.example.ui.screens.CallsHistoryScreen
import com.example.ui.screens.ChatRoomScreen
import com.example.ui.screens.ChatsScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.StatusScreen
import com.example.ui.theme.CipherChatTheme
import com.example.ui.viewmodel.MainViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val context = LocalContext.current
            val prefsStore = remember { UserPreferencesStore(context.applicationContext) }
            val settings by prefsStore.settingsFlow.collectAsStateWithLifecycle(
                initialValue = com.example.data.preferences.UserSettingsState()
            )
            val useDarkTheme = when (settings.themeMode) {
                ThemeMode.DARK -> true
                ThemeMode.LIGHT -> false
                ThemeMode.SYSTEM -> isSystemInDarkTheme()
            }

            CipherChatTheme(darkTheme = useDarkTheme) {
                AppContent()
            }
        }
    }
}

@Composable
fun AppContent() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember { CredentialManager.create(context) }

    var currentUser by remember { mutableStateOf<FirebaseUser?>(Firebase.auth.currentUser) }

    DisposableEffect(Unit) {
        val listener = FirebaseAuth.AuthStateListener { auth ->
            currentUser = auth.currentUser
        }
        Firebase.auth.addAuthStateListener(listener)
        onDispose { Firebase.auth.removeAuthStateListener(listener) }
    }

    LaunchedEffect(Unit) {
        if (Firebase.auth.currentUser == null) {
            attemptAutoSignIn(
                context = context,
                credentialManager = credentialManager,
                onAuthSuccess = { currentUser = Firebase.auth.currentUser },
                onUnauthenticated = {},
                scope = scope
            )
        }
    }

    val user = currentUser
    if (user == null) {
        AuthScreen(onAuthSuccess = { currentUser = Firebase.auth.currentUser })
    } else {
        val uid = user.uid
        key(uid) {
            AuthenticatedShell(
                currentUser = user,
                onSignOut = {
                    signOutUser(credentialManager, scope) {
                        currentUser = null
                    }
                }
            )
        }
    }
}

private data class NavTabItem(
    val labelRes: Int,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val tag: String
)

@Composable
private fun AuthenticatedShell(
    currentUser: FirebaseUser,
    onSignOut: () -> Unit
) {
    val uid = currentUser.uid
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    val viewModel: MainViewModel = viewModel(
        key = uid,
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY])
                val dbId = app.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(dbId)
                val crypto = E2eeCryptoManager(app)
                MainViewModel(
                    currentUserId = uid,
                    repository = CipherChatRepository(db = db, crypto = crypto),
                    crypto = crypto,
                    preferencesStore = UserPreferencesStore(app),
                    notificationManager = PresenceNotificationManager(app)
                )
            }
        }
    )

    LaunchedEffect(uid) {
        viewModel.bootstrapUser(currentUser)
    }

    DisposableEffect(lifecycleOwner, uid) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> viewModel.setOnlinePresence(true)
                Lifecycle.Event.ON_STOP -> viewModel.setOnlinePresence(false)
                else -> {}
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    val myProfileState by viewModel.myProfileState.collectAsStateWithLifecycle()
    val myPrivateState by viewModel.myPrivateState.collectAsStateWithLifecycle()
    val directoryState by viewModel.directoryUsersState.collectAsStateWithLifecycle()
    val conversationsState by viewModel.conversationsState.collectAsStateWithLifecycle()
    val messagesState by viewModel.selectedMessagesState.collectAsStateWithLifecycle()
    val statusesState by viewModel.statusUpdatesState.collectAsStateWithLifecycle()
    val callsState by viewModel.callsState.collectAsStateWithLifecycle()
    val settingsState by viewModel.settingsState.collectAsStateWithLifecycle()
    val selectedConversationId by viewModel.selectedConversationId.collectAsStateWithLifecycle()
    val activeCallId by viewModel.activeCallId.collectAsStateWithLifecycle()
    val statusBanner by viewModel.statusBanner.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(statusBanner) {
        statusBanner?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearBanner()
        }
    }

    val myProfile = (myProfileState as? UiState.Success)?.data
    val myPrivate = (myPrivateState as? UiState.Success)?.data
    val peers = (directoryState as? UiState.Success)?.data.orEmpty()
    val peersById = remember(peers) { peers.associateBy { it.userId } }
    val conversations = (conversationsState as? UiState.Success)?.data.orEmpty()
    val calls = (callsState as? UiState.Success)?.data.orEmpty()

    // Check for active outgoing/joined call OR incoming RINGING call
    val incomingRingingCall = calls.firstOrNull {
        it.calleeId == uid && it.status == CallStatus.RINGING.name
    }
    val activeCall = calls.firstOrNull {
        it.id == activeCallId && (it.status == CallStatus.RINGING.name || it.status == CallStatus.ACTIVE.name)
    } ?: incomingRingingCall

    if (activeCall != null) {
        ActiveCallScreen(
            call = activeCall,
            isIncomingRinging = activeCall.calleeId == uid && activeCall.status == CallStatus.RINGING.name,
            onAccept = { viewModel.joinCall(activeCall.id) },
            onDecline = { viewModel.declineCall(activeCall.id) },
            onEnd = { viewModel.endCall(activeCall.id) },
            onQualityChange = { tier -> viewModel.updateCallQuality(activeCall.id, tier) }
        )
        return
    }

    val selectedConversation = conversations.firstOrNull { it.id == selectedConversationId }
    if (selectedConversation != null) {
        val peerId = if (selectedConversation.conversationType == ConversationType.DIRECT.name) {
            selectedConversation.memberUids.firstOrNull { it != uid }
        } else null
        ChatRoomScreen(
            currentUserId = uid,
            myProfile = myProfile,
            conversation = selectedConversation,
            peerProfile = peerId?.let { peersById[it] },
            messagesState = messagesState,
            onBack = { viewModel.openConversation(null) },
            onSendText = { text -> viewModel.sendTextMessage(selectedConversation, text) },
            onSendVisualMedia = { uri, caption ->
                viewModel.sendVisualMediaMessage(context, selectedConversation, uri, caption)
            },
            onSendDocument = { uri ->
                viewModel.sendDocumentMessage(context, selectedConversation, uri)
            },
            onStartCall = { peer, callType ->
                viewModel.startCall(peer, selectedConversation.id, callType)
            }
        )
        return
    }

    var selectedTab by remember { mutableIntStateOf(0) }
    val navItems = remember {
        listOf(
            NavTabItem(R.string.tab_chats, Icons.Filled.ChatBubble, Icons.Outlined.ChatBubbleOutline, "nav_chats"),
            NavTabItem(R.string.tab_status, Icons.Filled.DonutLarge, Icons.Outlined.DonutLarge, "nav_status"),
            NavTabItem(R.string.tab_calls, Icons.Filled.Call, Icons.Outlined.Call, "nav_calls"),
            NavTabItem(R.string.tab_settings, Icons.Filled.Settings, Icons.Outlined.Settings, "nav_settings")
        )
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useRail = maxWidth >= 600.dp

        Scaffold(
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            bottomBar = {
                if (!useRail) {
                    NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                        navItems.forEachIndexed { idx, item ->
                            val selected = selectedTab == idx
                            NavigationBarItem(
                                selected = selected,
                                onClick = { selectedTab = idx },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                        contentDescription = stringResource(item.labelRes)
                                    )
                                },
                                label = { Text(stringResource(item.labelRes)) },
                                modifier = Modifier.testTag(item.tag)
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useRail) {
                    NavigationRail(containerColor = MaterialTheme.colorScheme.surface) {
                        navItems.forEachIndexed { idx, item ->
                            val selected = selectedTab == idx
                            NavigationRailItem(
                                selected = selected,
                                onClick = { selectedTab = idx },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                        contentDescription = stringResource(item.labelRes)
                                    )
                                },
                                label = { Text(stringResource(item.labelRes)) },
                                modifier = Modifier.testTag(item.tag)
                            )
                        }
                    }
                }

                Box(modifier = Modifier.weight(1f).fillMaxSize().statusBarsPadding()) {
                    when (selectedTab) {
                        0 -> ChatsScreen(
                            currentUserId = uid,
                            myProfile = myProfile,
                            conversationsState = conversationsState,
                            directoryUsersState = directoryState,
                            onOpenConversation = { conv -> viewModel.openConversation(conv.id) },
                            onStartDirectChat = { peer ->
                                viewModel.startOrOpenDirectChat(peer) { convId ->
                                    viewModel.openConversation(convId)
                                }
                            },
                            onCreateGroupChat = { title, selected ->
                                viewModel.createGroupChat(title, selected) { convId ->
                                    viewModel.openConversation(convId)
                                }
                            }
                        )
                        1 -> StatusScreen(
                            currentUserId = uid,
                            myProfile = myProfile,
                            statusesState = statusesState,
                            onPostTextStatus = { caption, hex -> viewModel.postTextStatus(caption, hex) },
                            onPostImageStatus = { uri, caption -> viewModel.postImageStatus(context, uri, caption) },
                            onMarkViewed = { status -> viewModel.markStatusViewed(status) }
                        )
                        2 -> CallsHistoryScreen(
                            currentUserId = uid,
                            callsState = callsState,
                            peers = peers,
                            onStartCall = { peer, callType ->
                                val convId = "dm_${listOf(uid, peer.userId).sorted().joinToString("_")}"
                                viewModel.startCall(peer, convId, callType)
                            }
                        )
                        3 -> SettingsScreen(
                            myProfile = myProfile,
                            myPrivate = myPrivate,
                            settings = settingsState,
                            onUpdateProfile = { name, handle, bio, preset, avatarB64, vis, disc ->
                                viewModel.updateProfile(name, handle, bio, preset, avatarB64, vis, disc)
                            },
                            onSavePhoneNumber = { phone -> viewModel.savePhoneNumber(phone) },
                            onSetThemeMode = { mode -> viewModel.setThemeMode(mode) },
                            onSetOnlineAlerts = { enabled -> viewModel.setOnlineAlertsEnabled(enabled) },
                            onSetReadReceipts = { enabled -> viewModel.setReadReceiptsEnabled(enabled) },
                            onSignOut = onSignOut
                        )
                    }
                }
            }
        }
    }
}
