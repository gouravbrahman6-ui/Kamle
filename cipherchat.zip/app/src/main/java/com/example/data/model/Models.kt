package com.example.data.model

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

enum class LastSeenVisibility(val label: String) {
    EVERYONE("Everyone"),
    CONTACTS("Friends Only"),
    NOBODY("Nobody");

    companion object {
        fun fromRaw(raw: String?): LastSeenVisibility =
            entries.firstOrNull { it.name == raw } ?: EVERYONE
    }
}

enum class ConversationType {
    DIRECT,
    GROUP;

    companion object {
        fun fromRaw(raw: String?): ConversationType =
            entries.firstOrNull { it.name == raw } ?: DIRECT
    }
}

enum class MessageType {
    NONE,
    TEXT,
    IMAGE,
    VIDEO,
    DOCUMENT,
    CALL;

    companion object {
        fun fromRaw(raw: String?): MessageType =
            entries.firstOrNull { it.name == raw } ?: TEXT
    }
}

enum class CallType {
    AUDIO,
    VIDEO;

    companion object {
        fun fromRaw(raw: String?): CallType =
            entries.firstOrNull { it.name == raw } ?: VIDEO
    }
}

enum class CallStatus {
    RINGING,
    ACTIVE,
    ENDED,
    DECLINED,
    MISSED;

    companion object {
        fun fromRaw(raw: String?): CallStatus =
            entries.firstOrNull { it.name == raw } ?: ENDED
    }
}

enum class QualityTier(val label: String) {
    HD_720P("720p HD"),
    FHD_1080P("1080p Full HD"),
    DATA_SAVER("Low Data");

    companion object {
        fun fromRaw(raw: String?): QualityTier =
            entries.firstOrNull { it.name == raw } ?: HD_720P
    }
}

@Keep
@IgnoreExtraProperties
data class UserPublic(
    @DocumentId val id: String = "",
    val userId: String = "",
    val displayName: String = "",
    val handle: String = "",
    val bio: String = "",
    val avatarPreset: String = "TEAL_SHIELD",
    val avatarBase64: String? = null,
    val publicKeyBase64: String = "",
    val keyFingerprint: String = "",
    val online: Boolean = false,
    val lastSeenVisibility: String = LastSeenVisibility.EVERYONE.name,
    val discoverable: Boolean = true,
    @ServerTimestamp val lastSeenAt: Timestamp? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class UserPrivate(
    @DocumentId val id: String = "",
    val userId: String = "",
    val email: String = "",
    val phoneNumber: String = "",
    val phoneVerified: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class Contact(
    @DocumentId val id: String = "",
    val userId: String = "",
    val contactUid: String = "",
    val contactName: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class Conversation(
    @DocumentId val id: String = "",
    val conversationType: String = ConversationType.DIRECT.name,
    val title: String = "",
    val createdBy: String = "",
    val memberUids: List<String> = emptyList(),
    val adminUids: List<String> = emptyList(),
    val lastMessagePreview: String = "",
    val lastMessageType: String = MessageType.NONE.name,
    val lastSenderId: String = "",
    val wrappedGroupKeys: Map<String, String> = emptyMap(),
    val memberNames: Map<String, String> = emptyMap(),
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class ChatMessage(
    @DocumentId val id: String = "",
    val conversationId: String = "",
    val senderId: String = "",
    val senderName: String = "",
    val memberUids: List<String> = emptyList(),
    val messageType: String = MessageType.TEXT.name,
    val encryptedPayload: String = "",
    val encrypted: Boolean = true,
    val attachmentName: String? = null,
    val attachmentMime: String? = null,
    val attachmentSizeBytes: Long = 0L,
    val encryptedMediaBase64: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class StatusUpdate(
    @DocumentId val id: String = "",
    val userId: String = "",
    val authorName: String = "",
    val authorAvatarPreset: String = "TEAL_SHIELD",
    val statusType: String = "TEXT",
    val caption: String = "",
    val backgroundHex: String = "#0F766E",
    val imageBase64: String? = null,
    val audience: String = "PUBLIC",
    val viewerUids: List<String> = emptyList(),
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class CallSession(
    @DocumentId val id: String = "",
    val callerId: String = "",
    val callerName: String = "",
    val calleeId: String = "",
    val calleeName: String = "",
    val conversationId: String = "",
    val memberUids: List<String> = emptyList(),
    val callType: String = CallType.VIDEO.name,
    val status: String = CallStatus.RINGING.name,
    val qualityTier: String = QualityTier.HD_720P.name,
    val e2eeFingerprint: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)
