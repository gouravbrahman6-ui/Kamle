package com.example.data.preferences

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.settingsDataStore by preferencesDataStore(name = "cipherchat_user_settings")

enum class ThemeMode {
    DARK,
    LIGHT,
    SYSTEM;

    companion object {
        fun fromRaw(raw: String?): ThemeMode =
            entries.firstOrNull { it.name == raw } ?: DARK
    }
}

data class UserSettingsState(
    val themeMode: ThemeMode = ThemeMode.DARK,
    val onlineAlertsEnabled: Boolean = true,
    val readReceiptsEnabled: Boolean = true,
    val preferredQuality: String = "HD_720P"
)

class UserPreferencesStore(private val context: Context) {

    private object Keys {
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val ONLINE_ALERTS = booleanPreferencesKey("online_alerts")
        val READ_RECEIPTS = booleanPreferencesKey("read_receipts")
        val CALL_QUALITY = stringPreferencesKey("call_quality")
    }

    val settingsFlow: Flow<UserSettingsState> = context.settingsDataStore.data.map { prefs ->
        UserSettingsState(
            themeMode = ThemeMode.fromRaw(prefs[Keys.THEME_MODE]),
            onlineAlertsEnabled = prefs[Keys.ONLINE_ALERTS] ?: true,
            readReceiptsEnabled = prefs[Keys.READ_RECEIPTS] ?: true,
            preferredQuality = prefs[Keys.CALL_QUALITY] ?: "HD_720P"
        )
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.settingsDataStore.edit { it[Keys.THEME_MODE] = mode.name }
    }

    suspend fun setOnlineAlertsEnabled(enabled: Boolean) {
        context.settingsDataStore.edit { it[Keys.ONLINE_ALERTS] = enabled }
    }

    suspend fun setReadReceiptsEnabled(enabled: Boolean) {
        context.settingsDataStore.edit { it[Keys.READ_RECEIPTS] = enabled }
    }

    suspend fun setPreferredCallQuality(quality: String) {
        context.settingsDataStore.edit { it[Keys.CALL_QUALITY] = quality }
    }
}
