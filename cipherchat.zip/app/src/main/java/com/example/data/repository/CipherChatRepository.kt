package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.crypto.E2eeCryptoManager
import com.example.data.firestore.OperationType
import com.example.data.firestore.handleFirestoreError
import com.example.data.model.CallSession
import com.example.data.model.CallStatus
import com.example.data.model.CallType
import com.example.data.model.ChatMessage
import com.example.data.model.Contact
import com.example.data.model.Conversation
import com.example.data.model.ConversationType
import com.example.data.model.LastSeenVisibility
import com.example.data.model.MessageType
import com.example.data.model.QualityTier
import com.example.data.model.StatusUpdate
import com.example.data.model.UserPrivate
import com.example.data.model.UserPublic
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import java.security.KeyPair
import javax.crypto.SecretKey
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class CipherChatRepository(
    private val db: FirebaseFirestore,
    private val crypto: E2eeCryptoManager,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        db = FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        ),
        crypto = E2eeCryptoManager(context.applicationContext)
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
    }

    private fun sanitizeId(raw: String): String =
        raw.replace(Regex("[^a-zA-Z0-9_\\-]"), "_").take(120)

    suspend fun getLocalKeyPair(userId: String): KeyPair =
        crypto.getOrCreateKeyPair(userId)

    suspend fun ensureUserProvisioned(firebaseUser: FirebaseUser): Result<UserPublic> {
        val uid = firebaseUser.uid
        val publicPath = "users_public/$uid"
        return try {
            require(uid == requireUserId()) { "Session UID mismatch" }
            val keyPair = crypto.getOrCreateKeyPair(uid)
            val pubB64 = crypto.publicKeyToBase64(keyPair.public)
            val fingerprint = crypto.computeFingerprint(pubB64)

            val pubRef = db.collection("users_public").document(uid)
            val existingPub = pubRef.get().await()
            val resultProfile: UserPublic

            if (!existingPub.exists()) {
                val defaultName = firebaseUser.displayName?.takeIf { it.isNotBlank() }
                    ?: firebaseUser.email?.substringBefore("@")?.take(30)
                    ?: "Cipher User"
                val rawHandle = (firebaseUser.email?.substringBefore("@") ?: "user_${uid.take(6)}")
                    .lowercase()
                    .replace(Regex("[^a-z0-9_]"), "_")
                    .take(30)
                    .let { if (it.length < 2) "u_$it" else it }

                val payload = mapOf(
                    "userId" to uid,
                    "displayName" to defaultName.take(60),
                    "handle" to rawHandle,
                    "bio" to "Encrypted on CipherChat",
                    "avatarPreset" to "TEAL_SHIELD",
                    "publicKeyBase64" to pubB64,
                    "keyFingerprint" to fingerprint,
                    "online" to true,
                    "lastSeenVisibility" to LastSeenVisibility.EVERYONE.name,
                    "discoverable" to true,
                    "lastSeenAt" to FieldValue.serverTimestamp(),
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                pubRef.set(payload).await()
                resultProfile = UserPublic(
                    id = uid,
                    userId = uid,
                    displayName = defaultName.take(60),
                    handle = rawHandle,
                    bio = "Encrypted on CipherChat",
                    avatarPreset = "TEAL_SHIELD",
                    publicKeyBase64 = pubB64,
                    keyFingerprint = fingerprint,
                    online = true,
                    lastSeenVisibility = LastSeenVisibility.EVERYONE.name,
                    discoverable = true
                )
            } else {
                val existingObj = existingPub.toObject(
                    UserPublic::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ) ?: UserPublic(id = uid, userId = uid)

                val updatePayload = mutableMapOf<String, Any>(
                    "online" to true,
                    "lastSeenAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                if (existingObj.publicKeyBase64 != pubB64) {
                    updatePayload["displayName"] = existingObj.displayName.ifBlank { "Cipher User" }
                    updatePayload["handle"] = existingObj.handle.ifBlank { "user_${uid.take(6)}" }
                    updatePayload["bio"] = existingObj.bio
                    updatePayload["avatarPreset"] = existingObj.avatarPreset.ifBlank { "TEAL_SHIELD" }
                    if (!existingObj.avatarBase64.isNullOrBlank()) {
                        updatePayload["avatarBase64"] = existingObj.avatarBase64
                    }
                    updatePayload["publicKeyBase64"] = pubB64
                    updatePayload["keyFingerprint"] = fingerprint
                    updatePayload["lastSeenVisibility"] = existingObj.lastSeenVisibility
                    updatePayload["discoverable"] = existingObj.discoverable
                }
                pubRef.update(updatePayload).await()
                resultProfile = existingObj.copy(
                    publicKeyBase64 = pubB64,
                    keyFingerprint = fingerprint,
                    online = true
                )
            }

            val privRef = db.collection("users_private").document(uid)
            val existingPriv = privRef.get().await()
            if (!existingPriv.exists()) {
                val privPayload = mapOf(
                    "userId" to uid,
                    "email" to (firebaseUser.email ?: "").take(160),
                    "phoneNumber" to (firebaseUser.phoneNumber ?: "").take(30),
                    "phoneVerified" to !firebaseUser.phoneNumber.isNullOrBlank(),
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                privRef.set(privPayload).await()
            }

            Result.success(resultProfile)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, publicPath)
            Result.failure(e)
        }
    }

    suspend fun updatePresence(userId: String, isOnlineNow: Boolean): Result<Unit> {
        val path = "users_public/$userId"
        return try {
            val uid = auth.currentUser?.uid ?: return Result.success(Unit)
            if (uid != userId) return Result.success(Unit)
            db.collection("users_public").document(userId).update(
                mapOf(
                    "online" to isOnlineNow,
                    "lastSeenAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun updateProfile(
        userId: String,
        displayName: String,
        handle: String,
        bio: String,
        avatarPreset: String,
        avatarBase64: String?,
        lastSeenVisibility: LastSeenVisibility,
        discoverable: Boolean
    ): Result<Unit> {
        val path = "users_public/$userId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Refusing cross-user profile update." }
            val cleanName = displayName.trim().take(60)
            val cleanHandle = handle.trim().lowercase().replace(Regex("[^a-z0-9_]"), "_").take(40)
            require(cleanName.isNotEmpty()) { "Display name cannot be empty." }
            require(cleanHandle.length >= 2) { "Handle must be at least 2 characters." }
            val keyPair = crypto.getOrCreateKeyPair(uid)
            val pubB64 = crypto.publicKeyToBase64(keyPair.public)
            val fingerprint = crypto.computeFingerprint(pubB64)

            val payload = mutableMapOf<String, Any>(
                "displayName" to cleanName,
                "handle" to cleanHandle,
                "bio" to bio.trim().take(200),
                "avatarPreset" to avatarPreset.take(40),
                "publicKeyBase64" to pubB64,
                "keyFingerprint" to fingerprint,
                "lastSeenVisibility" to lastSeenVisibility.name,
                "discoverable" to discoverable,
                "online" to true,
                "lastSeenAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (!avatarBase64.isNullOrBlank() && avatarBase64.length <= 300000) {
                payload["avatarBase64"] = avatarBase64
            }
            db.collection("users_public").document(uid).update(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun updatePhoneVerification(
        userId: String,
        phoneNumber: String,
        verified: Boolean
    ): Result<Unit> {
        val path = "users_private/$userId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Refusing cross-user phone update." }
            val cleanPhone = phoneNumber.trim().take(30)
            require(cleanPhone.length >= 6) { "Enter a valid phone number with country code." }
            db.collection("users_private").document(uid).update(
                mapOf(
                    "phoneNumber" to cleanPhone,
                    "phoneVerified" to verified,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    fun observeMyProfile(userId: String): Flow<UserPublic?> = flow {
        val uid = requireUserId()
        check(uid == userId)
        val path = "users_public/$userId"
        emitAll(
            db.collection("users_public").document(userId)
                .snapshots()
                .map { it.toObject(UserPublic::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
                .catch { error ->
                    val fsErr = unwrapFirestoreError(error)
                    if (fsErr == null && error is CancellationException) throw error
                    if (auth.currentUser?.uid == uid) {
                        handleFirestoreError(fsErr ?: error, OperationType.GET, path)
                    }
                    throw error
                }
        )
    }

    fun observePrivateProfile(userId: String): Flow<UserPrivate?> = flow {
        val uid = requireUserId()
        check(uid == userId)
        val path = "users_private/$userId"
        emitAll(
            db.collection("users_private").document(userId)
                .snapshots()
                .map { it.toObject(UserPrivate::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
                .catch { error ->
                    val fsErr = unwrapFirestoreError(error)
                    if (fsErr == null && error is CancellationException) throw error
                    if (auth.currentUser?.uid == uid) {
                        handleFirestoreError(fsErr ?: error, OperationType.GET, path)
                    }
                    throw error
                }
        )
    }

    fun observeDiscoverableUsers(): Flow<List<UserPublic>> = flow {
        val uid = requireUserId()
        val path = "users_public"
        emitAll(
            db.collection(path)
                .whereEqualTo("discoverable", true)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(UserPublic::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
                .catch { error ->
                    val fsErr = unwrapFirestoreError(error)
                    if (fsErr == null && error is CancellationException) throw error
                    if (auth.currentUser?.uid == uid) {
                        handleFirestoreError(fsErr ?: error, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observeContacts(userId: String): Flow<List<Contact>> = flow {
        val uid = requireUserId()
        check(uid == userId)
        val path = "users/$userId/contacts"
        emitAll(
            db.collection("users").document(userId).collection("contacts")
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(Contact::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
                .catch { error ->
                    val fsErr = unwrapFirestoreError(error)
                    if (fsErr == null && error is CancellationException) throw error
                    if (auth.currentUser?.uid == uid) {
                        handleFirestoreError(fsErr ?: error, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun addContact(userId: String, peer: UserPublic): Result<Unit> {
        val contactId = sanitizeId(peer.userId)
        val path = "users/$userId/contacts/$contactId"
        return try {
            val uid = requireUserId()
            check(uid == userId)
            val payload = mapOf(
                "userId" to uid,
                "contactUid" to peer.userId,
                "contactName" to peer.displayName.ifBlank { peer.handle }.take(60),
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            db.collection("users").document(uid).collection("contacts").document(contactId)
                .set(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    fun observeConversations(userId: String): Flow<List<Conversation>> = flow {
        val uid = requireUserId()
        check(uid == userId)
        val path = "conversations"
        emitAll(
            db.collection(path)
                .whereArrayContains("memberUids", userId)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(Conversation::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.updatedAt?.toDate()?.time ?: 0L }
                }
                .catch { error ->
                    val fsErr = unwrapFirestoreError(error)
                    if (fsErr == null && error is CancellationException) throw error
                    if (auth.currentUser?.uid == uid) {
                        handleFirestoreError(fsErr ?: error, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun createOrOpenDirectChat(
        me: UserPublic,
        peer: UserPublic
    ): Result<String> {
        val pair = listOf(me.userId, peer.userId).sorted()
        val convId = sanitizeId("dm_${pair[0]}_${pair[1]}")
        val path = "conversations/$convId"
        return try {
            val uid = requireUserId()
            check(uid == me.userId)
            val docRef = db.collection("conversations").document(convId)
            val existing = docRef.get().await()
            if (!existing.exists()) {
                val payload = mapOf(
                    "conversationType" to ConversationType.DIRECT.name,
                    "title" to peer.displayName.ifBlank { peer.handle }.take(80),
                    "createdBy" to uid,
                    "memberUids" to pair,
                    "adminUids" to pair,
                    "lastMessagePreview" to "End-to-end encrypted chat started",
                    "lastMessageType" to MessageType.NONE.name,
                    "lastSenderId" to uid,
                    "memberNames" to mapOf(
                        me.userId to me.displayName.ifBlank { "Me" },
                        peer.userId to peer.displayName.ifBlank { peer.handle }
                    ),
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.set(payload).await()
            }
            Result.success(convId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun createGroupChat(
        me: UserPublic,
        title: String,
        members: List<UserPublic>
    ): Result<String> {
        val docRef = db.collection("conversations").document()
        val path = docRef.path
        return try {
            val uid = requireUserId()
            check(uid == me.userId)
            val cleanTitle = title.trim().take(80)
            require(cleanTitle.isNotEmpty()) { "Group name cannot be empty." }

            val allMembers = (listOf(me) + members).distinctBy { it.userId }.take(50)
            require(allMembers.size >= 2) { "Select at least 1 friend for the group." }

            val myKeyPair = crypto.getOrCreateKeyPair(uid)
            val groupKey = crypto.generateRandomGroupKey()
            val wrappedKeys = mutableMapOf<String, String>()
            val memberNames = mutableMapOf<String, String>()

            for (member in allMembers) {
                memberNames[member.userId] = member.displayName.ifBlank { member.handle }
                if (member.publicKeyBase64.isNotBlank()) {
                    val wrapped = crypto.wrapGroupKeyForPeer(groupKey, myKeyPair.private, member.publicKeyBase64)
                    if (wrapped != null) {
                        wrappedKeys[member.userId] = wrapped
                    }
                }
            }

            val payload = mapOf(
                "conversationType" to ConversationType.GROUP.name,
                "title" to cleanTitle,
                "createdBy" to uid,
                "memberUids" to allMembers.map { it.userId },
                "adminUids" to listOf(uid),
                "lastMessagePreview" to "Group created with E2EE",
                "lastMessageType" to MessageType.NONE.name,
                "lastSenderId" to uid,
                "wrappedGroupKeys" to wrappedKeys,
                "memberNames" to memberNames,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            docRef.set(payload).await()
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun resolveConversationSecretKey(
        conversation: Conversation,
        myUserId: String,
        usersById: Map<String, UserPublic>
    ): SecretKey {
        val myKeys = crypto.getOrCreateKeyPair(myUserId)
        if (conversation.conversationType == ConversationType.DIRECT.name) {
            val peerId = conversation.memberUids.firstOrNull { it != myUserId } ?: myUserId
            val peerPub = usersById[peerId]?.publicKeyBase64
            if (!peerPub.isNullOrBlank()) {
                crypto.derivePairwiseAesKey(myKeys.private, peerPub)?.let { return it }
            }
        } else {
            val wrapped = conversation.wrappedGroupKeys[myUserId]
            val creatorPub = usersById[conversation.createdBy]?.publicKeyBase64
            if (!wrapped.isNullOrBlank() && !creatorPub.isNullOrBlank()) {
                crypto.unwrapGroupKeyFromPeer(wrapped, myKeys.private, creatorPub)?.let { return it }
            }
        }
        return crypto.deriveConversationFallbackKey(conversation.id)
    }

    fun observeMessages(conversationId: String, userId: String): Flow<List<ChatMessage>> = flow {
        val uid = requireUserId()
        check(uid == userId)
        val path = "conversations/$conversationId/messages"
        emitAll(
            db.collection("conversations").document(conversationId).collection("messages")
                .whereArrayContains("memberUids", userId)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(ChatMessage::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedBy { it.createdAt?.toDate()?.time ?: Long.MAX_VALUE }
                }
                .catch { error ->
                    val fsErr = unwrapFirestoreError(error)
                    if (fsErr == null && error is CancellationException) throw error
                    if (auth.currentUser?.uid == uid) {
                        handleFirestoreError(fsErr ?: error, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun sendEncryptedMessage(
        conversation: Conversation,
        sender: UserPublic,
        plainText: String,
        messageType: MessageType,
        secretKey: SecretKey,
        attachmentName: String? = null,
        attachmentMime: String? = null,
        attachmentSizeBytes: Long = 0L,
        rawMediaBytes: ByteArray? = null
    ): Result<Unit> {
        val msgRef = db.collection("conversations").document(conversation.id)
            .collection("messages").document()
        val path = msgRef.path
        return try {
            val uid = requireUserId()
            check(uid == sender.userId)
            val encryptedText = crypto.encryptText(plainText.ifBlank { attachmentName ?: "Encrypted message" }, secretKey)
            require(encryptedText.length <= 400000) { "Encrypted message exceeds size limit." }

            val encryptedMedia = rawMediaBytes?.let { bytes ->
                val enc = crypto.encryptBytes(bytes, secretKey)
                require(enc.length <= 700000) { "Media payload exceeds 700KB encrypted inline limit." }
                enc
            }

            val payload = mutableMapOf<String, Any>(
                "conversationId" to conversation.id,
                "senderId" to uid,
                "senderName" to sender.displayName.ifBlank { sender.handle }.take(60),
                "memberUids" to conversation.memberUids.take(50),
                "messageType" to messageType.name,
                "encryptedPayload" to encryptedText,
                "encrypted" to true,
                "attachmentSizeBytes" to attachmentSizeBytes.coerceIn(0L, 25000000L),
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            attachmentName?.take(200)?.let { payload["attachmentName"] = it }
            attachmentMime?.take(120)?.let { payload["attachmentMime"] = it }
            encryptedMedia?.let { payload["encryptedMediaBase64"] = it }

            val previewLabel = when (messageType) {
                MessageType.IMAGE -> "Encrypted Photo"
                MessageType.VIDEO -> "Encrypted Video"
                MessageType.DOCUMENT -> "Encrypted Doc: ${attachmentName ?: "File"}"
                MessageType.CALL -> "Encrypted Call"
                else -> "Encrypted message"
            }.take(300)

            val batch = db.batch()
            batch.set(msgRef, payload)
            batch.update(
                db.collection("conversations").document(conversation.id),
                mapOf(
                    "lastMessagePreview" to previewLabel,
                    "lastMessageType" to messageType.name,
                    "lastSenderId" to uid,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    fun observePublicStatuses(): Flow<List<StatusUpdate>> = flow {
        val uid = requireUserId()
        val path = "status_updates"
        emitAll(
            db.collection(path)
                .whereEqualTo("audience", "PUBLIC")
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(StatusUpdate::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.toDate()?.time ?: 0L }
                }
                .catch { error ->
                    val fsErr = unwrapFirestoreError(error)
                    if (fsErr == null && error is CancellationException) throw error
                    if (auth.currentUser?.uid == uid) {
                        handleFirestoreError(fsErr ?: error, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun postStatusUpdate(
        author: UserPublic,
        caption: String,
        backgroundHex: String,
        imageBase64: String?
    ): Result<Unit> {
        val ref = db.collection("status_updates").document()
        val path = ref.path
        return try {
            val uid = requireUserId()
            check(uid == author.userId)
            val statusType = if (!imageBase64.isNullOrBlank()) "IMAGE" else "TEXT"
            val payload = mutableMapOf<String, Any>(
                "userId" to uid,
                "authorName" to author.displayName.ifBlank { author.handle }.take(60),
                "authorAvatarPreset" to author.avatarPreset.ifBlank { "TEAL_SHIELD" }.take(40),
                "statusType" to statusType,
                "caption" to caption.trim().take(500),
                "backgroundHex" to backgroundHex.take(20),
                "audience" to "PUBLIC",
                "viewerUids" to emptyList<String>(),
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (!imageBase64.isNullOrBlank() && imageBase64.length <= 400000) {
                payload["imageBase64"] = imageBase64
            }
            ref.set(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun markStatusViewed(status: StatusUpdate, viewerUid: String): Result<Unit> {
        if (status.id.isBlank() || status.viewerUids.contains(viewerUid) || status.viewerUids.size >= 100) {
            return Result.success(Unit)
        }
        val path = "status_updates/${status.id}"
        return try {
            requireUserId()
            db.collection("status_updates").document(status.id).update(
                mapOf(
                    "viewerUids" to (status.viewerUids + viewerUid).distinct().take(100),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    fun observeCalls(userId: String): Flow<List<CallSession>> = flow {
        val uid = requireUserId()
        check(uid == userId)
        val path = "calls"
        emitAll(
            db.collection(path)
                .whereArrayContains("memberUids", userId)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(CallSession::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.toDate()?.time ?: 0L }
                }
                .catch { error ->
                    val fsErr = unwrapFirestoreError(error)
                    if (fsErr == null && error is CancellationException) throw error
                    if (auth.currentUser?.uid == uid) {
                        handleFirestoreError(fsErr ?: error, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun startCall(
        caller: UserPublic,
        callee: UserPublic,
        conversationId: String,
        callType: CallType,
        qualityTier: QualityTier
    ): Result<CallSession> {
        val ref = db.collection("calls").document()
        val path = ref.path
        return try {
            val uid = requireUserId()
            check(uid == caller.userId)
            val fingerprint = caller.keyFingerprint.ifBlank { "E2EE-VERIFIED" }.take(64)
            val payload = mapOf(
                "callerId" to uid,
                "callerName" to caller.displayName.ifBlank { caller.handle }.take(60),
                "calleeId" to callee.userId,
                "calleeName" to callee.displayName.ifBlank { callee.handle }.take(60),
                "conversationId" to sanitizeId(conversationId),
                "memberUids" to listOf(uid, callee.userId),
                "callType" to callType.name,
                "status" to CallStatus.RINGING.name,
                "qualityTier" to qualityTier.name,
                "e2eeFingerprint" to fingerprint,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            ref.set(payload).await()
            Result.success(
                CallSession(
                    id = ref.id,
                    callerId = uid,
                    callerName = caller.displayName.ifBlank { caller.handle }.take(60),
                    calleeId = callee.userId,
                    calleeName = callee.displayName.ifBlank { callee.handle }.take(60),
                    conversationId = sanitizeId(conversationId),
                    memberUids = listOf(uid, callee.userId),
                    callType = callType.name,
                    status = CallStatus.RINGING.name,
                    qualityTier = qualityTier.name,
                    e2eeFingerprint = fingerprint
                )
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun updateCallStatus(
        callId: String,
        newStatus: CallStatus,
        qualityTier: QualityTier? = null
    ): Result<Unit> {
        val path = "calls/$callId"
        return try {
            requireUserId()
            require(callId.isNotBlank())
            val updates = mutableMapOf<String, Any>(
                "status" to newStatus.name,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            qualityTier?.let { updates["qualityTier"] = it.name }
            db.collection("calls").document(callId).update(updates).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    private fun unwrapFirestoreError(error: Throwable): FirebaseFirestoreException? =
        generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
}
