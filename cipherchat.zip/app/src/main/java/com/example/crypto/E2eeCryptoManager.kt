package com.example.crypto

import android.content.Context
import android.util.Base64
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.PublicKey
import java.security.SecureRandom
import java.security.spec.ECGenParameterSpec
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.X509EncodedKeySpec
import javax.crypto.Cipher
import javax.crypto.KeyAgreement
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

private val Context.cryptoDataStore by preferencesDataStore(name = "cipherchat_e2ee_keys")

class E2eeCryptoManager(private val context: Context) {

    private val mutex = Mutex()
    private val secureRandom = SecureRandom()

    suspend fun getOrCreateKeyPair(userId: String): KeyPair = mutex.withLock {
        val privKeyPref = stringPreferencesKey("ec_priv_$userId")
        val pubKeyPref = stringPreferencesKey("ec_pub_$userId")
        val prefs = context.cryptoDataStore.data.first()
        val storedPriv = prefs[privKeyPref]
        val storedPub = prefs[pubKeyPref]

        if (!storedPriv.isNullOrBlank() && !storedPub.isNullOrBlank()) {
            return@withLock runCatching {
                val kf = KeyFactory.getInstance("EC")
                val priv = kf.generatePrivate(PKCS8EncodedKeySpec(Base64.decode(storedPriv, Base64.NO_WRAP)))
                val pub = kf.generatePublic(X509EncodedKeySpec(Base64.decode(storedPub, Base64.NO_WRAP)))
                KeyPair(pub, priv)
            }.getOrElse { generateAndStoreKeyPair(userId, privKeyPref, pubKeyPref) }
        }
        generateAndStoreKeyPair(userId, privKeyPref, pubKeyPref)
    }

    private suspend fun generateAndStoreKeyPair(
        userId: String,
        privKeyPref: androidx.datastore.preferences.core.Preferences.Key<String>,
        pubKeyPref: androidx.datastore.preferences.core.Preferences.Key<String>
    ): KeyPair {
        val kpg = KeyPairGenerator.getInstance("EC")
        kpg.initialize(ECGenParameterSpec("secp256r1"), secureRandom)
        val kp = kpg.generateKeyPair()
        val privB64 = Base64.encodeToString(kp.private.encoded, Base64.NO_WRAP)
        val pubB64 = Base64.encodeToString(kp.public.encoded, Base64.NO_WRAP)
        context.cryptoDataStore.edit { editPrefs ->
            editPrefs[privKeyPref] = privB64
            editPrefs[pubKeyPref] = pubB64
        }
        return kp
    }

    fun publicKeyToBase64(publicKey: PublicKey): String =
        Base64.encodeToString(publicKey.encoded, Base64.NO_WRAP)

    fun computeFingerprint(publicKeyBase64: String): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(publicKeyBase64.toByteArray(Charsets.UTF_8))
        val hex = digest.take(8).joinToString("") { "%02X".format(it) }
        return hex.chunked(4).joinToString("-")
    }

    fun derivePairwiseAesKey(myPrivateKey: PrivateKey, peerPublicKeyBase64: String): SecretKey? {
        return runCatching {
            val kf = KeyFactory.getInstance("EC")
            val peerBytes = Base64.decode(peerPublicKeyBase64, Base64.NO_WRAP)
            val peerPub = kf.generatePublic(X509EncodedKeySpec(peerBytes))
            val ka = KeyAgreement.getInstance("ECDH")
            ka.init(myPrivateKey)
            ka.doPhase(peerPub, true)
            val sharedSecret = ka.generateSecret()
            val aesBytes = MessageDigest.getInstance("SHA-256").digest(sharedSecret)
            SecretKeySpec(aesBytes, "AES")
        }.getOrNull()
    }

    fun generateRandomGroupKey(): SecretKey {
        val kg = KeyGenerator.getInstance("AES")
        kg.init(256, secureRandom)
        return kg.generateKey()
    }

    fun wrapGroupKeyForPeer(
        groupKey: SecretKey,
        myPrivateKey: PrivateKey,
        peerPublicKeyBase64: String
    ): String? {
        val pairwise = derivePairwiseAesKey(myPrivateKey, peerPublicKeyBase64) ?: return null
        return encryptBytes(groupKey.encoded, pairwise)
    }

    fun unwrapGroupKeyFromPeer(
        wrappedKeyBase64: String,
        myPrivateKey: PrivateKey,
        peerPublicKeyBase64: String
    ): SecretKey? {
        val pairwise = derivePairwiseAesKey(myPrivateKey, peerPublicKeyBase64) ?: return null
        val raw = decryptBytes(wrappedKeyBase64, pairwise) ?: return null
        return SecretKeySpec(raw, "AES")
    }

    fun encryptText(plainText: String, key: SecretKey): String {
        return encryptBytes(plainText.toByteArray(Charsets.UTF_8), key)
    }

    fun decryptText(payload: String, key: SecretKey): String? {
        val bytes = decryptBytes(payload, key) ?: return null
        return String(bytes, Charsets.UTF_8)
    }

    fun encryptBytes(plainBytes: ByteArray, key: SecretKey): String {
        val iv = ByteArray(12)
        secureRandom.nextBytes(iv)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, iv))
        val cipherBytes = cipher.doFinal(plainBytes)
        val ivB64 = Base64.encodeToString(iv, Base64.NO_WRAP)
        val ctB64 = Base64.encodeToString(cipherBytes, Base64.NO_WRAP)
        return "$ivB64:$ctB64"
    }

    fun decryptBytes(payload: String, key: SecretKey): ByteArray? {
        return runCatching {
            val parts = payload.split(":")
            if (parts.size != 2) return null
            val iv = Base64.decode(parts[0], Base64.NO_WRAP)
            val cipherBytes = Base64.decode(parts[1], Base64.NO_WRAP)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
            cipher.doFinal(cipherBytes)
        }.getOrNull()
    }

    fun deriveConversationFallbackKey(conversationId: String): SecretKey {
        val digest = MessageDigest.getInstance("SHA-256").digest("cipherchat:$conversationId".toByteArray(Charsets.UTF_8))
        return SecretKeySpec(digest, "AES")
    }
}
